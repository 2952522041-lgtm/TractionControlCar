# 相机配置
CAMERA_CONFIG = {
    'index': 0,
    'exposure_time': 10000,
    'gain': 0,
    'frame_rate': 25
}

# CAMERA_CONFIG = {
#     'index': 0,
#     'exposure_time': 12000,
#     'gain': 5,
#     'frame_rate': 25
# }

# # ROI配置
# ROI_CONFIG = {
#     'x': 780,
#     'y': 250,
#     'width': 1000,
#     'height': 1000
# }
# ROI配置
ROI_CONFIG = {
    'x': 120,
    'y': 130,
    'width': 1600,
    'height': 1500
}
# 机械臂配置
ROBOT_CONFIG = {
    'ip': "192.168.5.1",
    'ports': [29999, 30003, 30004]
}

# 串口配置
SERIAL_CONFIG = {
    'port': 'COM5',
    'baud_rate': 9600
}