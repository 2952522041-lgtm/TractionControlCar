"""机器人控制系统UI模块

本模块提供机器人控制系统的图形用户界面，包括电机控制、
系统暂停/恢复、录制控制和状态显示等功能。

主要功能：
1. 提供电机开关和参数控制
2. 提供系统暂停/恢复控制
3. 提供视频录制和轨迹记录的统一控制
4. 提供系统状态实时显示
"""

import threading
import time
import cv2
import numpy as np
from PyQt5.QtWidgets import (QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout,
                             QWidget, QLabel, QGroupBox, QGridLayout, QDoubleSpinBox,
                             QComboBox)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QFont, QImage, QPixmap
from PyQt5.QtWidgets import QApplication

class RobotControlUI(QMainWindow):
    """
    机器人控制系统图形用户界面
    
    提供按钮控制机器人系统的各项功能，包括电机控制、
    暂停/恢复系统、视频录制和轨迹记录的统一控制，
    以及显示系统状态等。
    """
    def __init__(self, status_info, logger, global_vars,
             camera_thread, motion_thread, motor, data_recorder):
        super().__init__()
        self.status_info = status_info
        self.logger = logger
        # 使用全局变量的引用对象
        self.global_vars = global_vars
        self.camera_thread = camera_thread
        self.motion_thread = motion_thread
        self.motor = motor
        self.data_recorder = data_recorder
        self.initUI()
        self.status_timer = QTimer()
        self.status_timer.timeout.connect(self.update_status)
        self.status_timer.start(500)  # 每500毫秒更新一次状态
        
    # 添加信号用于更新图像
    raw_image_signal = pyqtSignal(np.ndarray)
    processed_image_signal = pyqtSignal(np.ndarray)
    
    def initUI(self):
        """初始化用户界面"""
        self.setWindowTitle('多足机器人控制系统')
        self.setGeometry(100, 100, 1200, 1200)  # 增加窗口大小以容纳图像
        
        # 创建主布局
        main_layout = QVBoxLayout()
        
        # 创建控制按钮组
        control_group = QGroupBox("系统控制")
        control_layout = QGridLayout()
        
        # 创建按钮
        
        self.pause_btn = QPushButton("暂停系统")
        self.pause_btn.clicked.connect(self.toggle_pause)
        
        # 添加电机控制组
        motor_group = QGroupBox("电机控制")
        motor_layout = QGridLayout()

        
        # 添加转速输入框
        speed_label = QLabel("转速 (Hz):")
        self.speed_input = QDoubleSpinBox()
        self.speed_input.setRange(0.01, 20.0)
        self.speed_input.setValue(0.1)
        self.speed_input.setSingleStep(0.01)
        
        # 添加方向选择框
        direction_label = QLabel("旋转方向:")
        self.direction_input = QComboBox()
        self.direction_input.addItems(["正转", "反转"])

        # 添加电机控制按钮
        self.motor_on_btn = QPushButton("开启电机（匀速）")
        self.motor_on_btn.clicked.connect(self.motor_on)
        
        self.motor_on_biansu_btn = QPushButton("开启电机（变速）")
        self.motor_on_biansu_btn.clicked.connect(self.motor_on_biansu)
        
        self.motor_home_btn = QPushButton("电机回零")
        self.motor_home_btn.clicked.connect(self.motor_home)
        
        self.motor_off_btn = QPushButton("关闭电机")
        self.motor_off_btn.clicked.connect(self.motor_off)
        
        # 添加actuation控制按钮
        self.actuation_start_btn = QPushButton("启动Actuation")
        self.actuation_start_btn.clicked.connect(self.start_actuation)
        
        self.actuation_stop_btn = QPushButton("停止Actuation")
        self.actuation_stop_btn.clicked.connect(self.stop_actuation)
        
        # 添加控制序列按钮
        self.sequence_start_btn = QPushButton("启动控制序列")
        self.sequence_start_btn.clicked.connect(self.start_sequence)
        
        self.sequence_stop_btn = QPushButton("停止控制序列")
        self.sequence_stop_btn.clicked.connect(self.stop_sequence)
        
        # 将电机控制组件添加到布局
        motor_layout.addWidget(speed_label, 0, 0)
        motor_layout.addWidget(self.speed_input, 0, 1)
        motor_layout.addWidget(direction_label, 1, 0)
        motor_layout.addWidget(self.direction_input, 1, 1)
        motor_layout.addWidget(self.motor_on_btn, 2, 0)
        motor_layout.addWidget(self.motor_off_btn, 2, 1)
        motor_layout.addWidget(self.motor_on_biansu_btn, 3, 0)
        motor_layout.addWidget(self.motor_home_btn, 3, 1)
        motor_layout.addWidget(self.actuation_start_btn, 4, 0)
        motor_layout.addWidget(self.actuation_stop_btn, 4, 1)
        motor_layout.addWidget(self.sequence_start_btn, 5, 0)
        motor_layout.addWidget(self.sequence_stop_btn, 5, 1)

        motor_group.setLayout(motor_layout)
        
        self.exit_btn = QPushButton("退出程序")
        self.exit_btn.clicked.connect(self.exit_program)
        self.exit_btn.setStyleSheet("background-color: #FF6B6B;")
        
        # 添加合并的录制按钮（同时录制视频和轨迹）
        self.record_btn = QPushButton("开始录制（视频+轨迹）")
        self.record_btn.clicked.connect(self.toggle_recording)
        
        self.clear_trajectory_btn = QPushButton("清除轨迹")
        self.clear_trajectory_btn.clicked.connect(self.clear_trajectory)
        
        self.save_data_btn = QPushButton("保存数据")
        self.save_data_btn.clicked.connect(self.save_data)
        
        # 添加按钮到布局
        control_layout.addWidget(self.pause_btn, 0, 0)
        control_layout.addWidget(self.exit_btn, 0, 1)
        control_layout.addWidget(self.record_btn, 1, 0)
        control_layout.addWidget(self.clear_trajectory_btn, 1, 1)
        control_layout.addWidget(self.save_data_btn, 2, 0)
        
        control_group.setLayout(control_layout)
        
        # 创建状态显示组
        status_group = QGroupBox("系统状态")
        status_layout = QGridLayout()
        
        # 在initUI方法中添加朝向标签
        # 创建状态标签
        self.camera_status_label = QLabel("相机状态: 未连接")
        self.dobot_status_label = QLabel("机械臂状态: 未连接")
        self.motor_status_label = QLabel("电机状态: 未连接")
        self.system_status_label = QLabel("系统状态: 未启动")
        self.actuation_status_label = QLabel("Actuation状态: 未启动")
        self.rz_frozen_status_label = QLabel("RZ冻结状态: 未冻结")
        self.target_coord_label = QLabel("目标坐标: 无")
        self.pose_label = QLabel("当前位姿: 无")
        self.command_label = QLabel("发送命令: 无")
        self.alpha_cmd_label = QLabel("当前角度命令: 无")
        self.orientation_label = QLabel("机器人朝向: 无")  # 添加朝向标签
        self.pose_diff_label = QLabel("位姿差值: 无")  # 添加位姿差值标签
        self.alpha0_deg_label = QLabel("初始角度: 无")  # 添加初始角度标签
        self.delta_alpha_deg_label = QLabel("角度补偿: 无")  # 添加角度补偿标签
        self.psi_v_label = QLabel("速度方向: 无")  # 添加速度方向标签
        self.psi_v_hat_label = QLabel("ESO观测速度方向: 无")  # 添加ESO观测速度方向标签
        self.distur_hat_label = QLabel("ESO扰动估计: 无")  # 添加ESO扰动估计标签
        self.eso_comp_deg_label = QLabel("ESO补偿角度: 无")  # 添加ESO补偿角度标签
        self.alpha_cmd_eso_deg_label = QLabel("ESO补偿后角度命令: 无")  # 添加ESO补偿后角度命令标签
        self.signed_dist_label = QLabel("到轨迹距离: 无")  # 添加到轨迹的有向距离标签
        self.sequence_status_label = QLabel("控制序列状态: 未启动")  # 添加控制序列状态标签
        self.sequence_step_label = QLabel("当前步骤: 无")  # 添加当前步骤标签
        
        # 设置标签字体
        font = QFont()
        font.setPointSize(10)
        self.camera_status_label.setFont(font)
        self.dobot_status_label.setFont(font)
        self.motor_status_label.setFont(font)
        self.system_status_label.setFont(font)
        self.actuation_status_label.setFont(font)
        self.rz_frozen_status_label.setFont(font)
        self.target_coord_label.setFont(font)
        self.pose_label.setFont(font)
        self.command_label.setFont(font)
        self.alpha_cmd_label.setFont(font)
        self.orientation_label.setFont(font)  # 设置朝向标签字体
        self.pose_diff_label.setFont(font)  # 设置位姿差值标签字体
        self.alpha0_deg_label.setFont(font)  # 设置初始角度标签字体
        self.delta_alpha_deg_label.setFont(font)  # 设置角度补偿标签字体
        self.psi_v_label.setFont(font)  # 设置速度方向标签字体
        self.psi_v_hat_label.setFont(font)  # 设置ESO观测速度方向标签字体
        self.distur_hat_label.setFont(font)  # 设置ESO扰动估计标签字体
        self.eso_comp_deg_label.setFont(font)  # 设置ESO补偿角度标签字体
        self.alpha_cmd_eso_deg_label.setFont(font)  # 设置ESO补偿后角度命令标签字体
        self.signed_dist_label.setFont(font)  # 设置到轨迹的有向距离标签字体
        self.sequence_status_label.setFont(font)  # 设置控制序列状态标签字体
        self.sequence_step_label.setFont(font)  # 设置当前步骤标签字体
        
        # 添加标签到布局
        status_layout.addWidget(self.camera_status_label, 0, 0)
        status_layout.addWidget(self.dobot_status_label, 0, 1)
        status_layout.addWidget(self.motor_status_label, 1, 0)
        status_layout.addWidget(self.system_status_label, 1, 1)
        status_layout.addWidget(self.actuation_status_label, 2, 0)
        status_layout.addWidget(self.rz_frozen_status_label, 2, 1)
        status_layout.addWidget(self.pose_label, 3, 1)
        status_layout.addWidget(self.command_label, 4, 0)
        status_layout.addWidget(self.alpha_cmd_label, 4, 1)
        status_layout.addWidget(self.orientation_label, 5, 0)  # 添加朝向标签到布局
        status_layout.addWidget(self.pose_diff_label, 5, 1)  # 添加位姿差值标签到布局
        status_layout.addWidget(self.alpha0_deg_label, 6, 0)  # 添加初始角度标签到布局
        status_layout.addWidget(self.delta_alpha_deg_label, 6, 1)  # 添加角度补偿标签到布局
        status_layout.addWidget(self.psi_v_label, 7, 0)  # 添加速度方向标签到布局
        status_layout.addWidget(self.psi_v_hat_label, 7, 1)  # 添加ESO观测速度方向标签到布局
        status_layout.addWidget(self.distur_hat_label, 8, 0)  # 添加ESO扰动估计标签到布局
        status_layout.addWidget(self.eso_comp_deg_label, 8, 1)  # 添加ESO补偿角度标签到布局
        status_layout.addWidget(self.alpha_cmd_eso_deg_label, 9, 0)  # 添加ESO补偿后角度命令标签到布局
        status_layout.addWidget(self.signed_dist_label, 9, 1)  # 添加到轨迹的有向距离标签到布局
        status_layout.addWidget(self.target_coord_label, 10, 0)  # 添加目标坐标标签到布局
        status_layout.addWidget(self.sequence_status_label, 11, 0)  # 添加控制序列状态标签到布局
        status_layout.addWidget(self.sequence_step_label, 11, 1)  # 添加当前步骤标签到布局
        
        status_group.setLayout(status_layout)
        
        # 创建图像显示组
        image_group = QGroupBox("相机图像")
        image_layout = QHBoxLayout()
        
        # 创建两个图像标签
        self.raw_image_label = QLabel("等待原始图像...")
        self.raw_image_label.setMinimumSize(600, 600)
        self.raw_image_label.setAlignment(Qt.AlignCenter)
        self.raw_image_label.setStyleSheet("border: 1px solid #cccccc;")
        
        self.processed_image_label = QLabel("等待处理后图像...")
        self.processed_image_label.setMinimumSize(600, 600)
        self.processed_image_label.setAlignment(Qt.AlignCenter)
        self.processed_image_label.setStyleSheet("border: 1px solid #cccccc;")
        
        # 添加图像标签到布局
        image_layout.addWidget(self.raw_image_label)
        image_layout.addWidget(self.processed_image_label)
        image_group.setLayout(image_layout)
        
        # 添加组到主布局
        main_layout.addWidget(control_group)
        main_layout.addWidget(motor_group)  # 添加电机控制组
        main_layout.addWidget(status_group)
        main_layout.addWidget(image_group)  # 添加图像显示组
        
        # 设置主窗口的中央部件
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)
        
        # 连接信号到槽
        self.raw_image_signal.connect(self.update_raw_image)
        self.processed_image_signal.connect(self.update_processed_image)
        
        # 设置actuation按钮初始状态
        self.actuation_start_btn.setEnabled(True)
        self.actuation_stop_btn.setEnabled(False)
        
        # 设置控制序列按钮初始状态
        self.sequence_start_btn.setEnabled(True)
        self.sequence_stop_btn.setEnabled(False)
    
    def update_status(self):
        """更新状态显示"""
        try:
            # 创建状态信息的副本
            status_copy = self.status_info.copy()
            
            # 使用副本更新UI
            self.camera_status_label.setText(f"相机状态: {status_copy['camera']}")
            self.dobot_status_label.setText(f"机械臂状态: {status_copy['dobot']}")
            self.motor_status_label.setText(f"电机状态: {status_copy['motor']}")
            self.system_status_label.setText(f"系统状态: {status_copy['system']}")
            self.actuation_status_label.setText(f"Actuation状态: {status_copy['actuation']}")
            
            # 添加rz_frozen状态显示更新
            if 'rz_frozen' in status_copy:
                self.rz_frozen_status_label.setText(f"RZ冻结状态: {status_copy['rz_frozen']}")
            
            self.target_coord_label.setText(f"目标坐标: {status_copy['target']}")
            self.pose_label.setText(f"当前位姿: {status_copy['pose']}")
            
            # 添加发送命令显示更新
            if 'command' in status_copy:
                self.command_label.setText(f"发送命令: {status_copy['command']}")
                
            # 添加alpha_cmd显示更新
            if 'alpha_cmd' in status_copy:
                self.alpha_cmd_label.setText(f"当前角度命令: {status_copy['alpha_cmd']}")
                
            # 添加alpha0_deg显示更新
            if 'alpha0_deg' in status_copy:
                self.alpha0_deg_label.setText(f"初始角度: {status_copy['alpha0_deg']}°")
                
            # 添加delta_alpha_deg显示更新
            if 'delta_alpha_deg' in status_copy:
                self.delta_alpha_deg_label.setText(f"角度补偿: {status_copy['delta_alpha_deg']}°")
                
            # 添加速度方向显示更新
            if 'psi_v' in status_copy:
                self.psi_v_label.setText(f"速度方向: {status_copy['psi_v']}")
                
            # 添加ESO观测速度方向显示更新
            if 'psi_v_hat' in status_copy:
                self.psi_v_hat_label.setText(f"ESO观测速度方向: {status_copy['psi_v_hat']}°")
                
            # 添加ESO扰动估计显示更新
            if 'distur_hat' in status_copy:
                self.distur_hat_label.setText(f"ESO扰动估计: {status_copy['distur_hat']}")
                
            # 添加ESO补偿角度显示更新
            if 'eso_comp_deg' in status_copy:
                self.eso_comp_deg_label.setText(f"ESO补偿角度: {status_copy['eso_comp_deg']}°")
                
            # 添加ESO补偿后角度命令显示更新
            if 'alpha_cmd_eso_deg' in status_copy:
                self.alpha_cmd_eso_deg_label.setText(f"ESO补偿后角度命令: {status_copy['alpha_cmd_eso_deg']}°")
                
            # 添加到轨迹的有向距离显示更新
            if 'signed_dist' in status_copy:
                self.signed_dist_label.setText(f"到轨迹距离: {status_copy['signed_dist']} px")
                
            # 添加朝向显示更新
            if 'orientation' in status_copy:
                self.orientation_label.setText(f"机器人朝向: {status_copy['orientation']}")
            
            # 计算并更新位姿差值
            if 'pose' in status_copy and 'command' in status_copy and status_copy['pose'] != '无' and status_copy['command'] != '无':
                try:
                    # 解析当前位姿和命令位姿
                    pose_str = status_copy['pose']
                    cmd_str = status_copy['command']
                    
                    # 提取位姿参数
                    pose_values = {}
                    for part in pose_str.split(', '):
                        key, value = part.split('=')
                        pose_values[key] = float(value)
                    
                    # 提取命令参数
                    cmd_values = {}
                    for part in cmd_str.split(', '):
                        key, value = part.split('=')
                        cmd_values[key] = float(value)
                    
                    # 计算差值
                    diff_x = pose_values['X'] - cmd_values['X']
                    diff_y = pose_values['Y'] - cmd_values['Y']
                    diff_z = pose_values['Z'] - cmd_values['Z']
                    diff_rx = pose_values['RX'] - cmd_values['RX']
                    diff_ry = pose_values['RY'] - cmd_values['RY']
                    diff_rz = pose_values['RZ'] - cmd_values['RZ']
                    
                    # 更新差值显示
                    diff_text = f"ΔX={diff_x:.2f}, ΔY={diff_y:.2f}, ΔZ={diff_z:.2f}, ΔRX={diff_rx:.2f}, ΔRY={diff_ry:.2f}, ΔRZ={diff_rz:.2f}"
                    self.pose_diff_label.setText(f"位姿差值: {diff_text}")
                except Exception as e:
                    self.logger.error(f"计算位姿差值失败: {e}")
                    self.pose_diff_label.setText("位姿差值: 计算错误")
            else:
                self.pose_diff_label.setText("位姿差值: 无")
            
            # 更新控制序列状态
            if 'sequence' in status_copy:
                if status_copy['sequence']:
                    self.sequence_status_label.setText("控制序列状态: 运行中")
                    self.sequence_start_btn.setEnabled(False)
                    self.sequence_stop_btn.setEnabled(True)
                else:
                    self.sequence_status_label.setText("控制序列状态: 已停止")
                    self.sequence_start_btn.setEnabled(True)
                    self.sequence_stop_btn.setEnabled(False)
            
            # 更新当前步骤
            if 'sequence_step' in status_copy:
                try:
                    step_num = int(status_copy['sequence_step'])
                    if step_num > 0:
                        self.sequence_step_label.setText(f"当前步骤: 步骤{step_num}")
                    else:
                        self.sequence_step_label.setText("当前步骤: 无")
                except (ValueError, TypeError):
                    self.sequence_step_label.setText("当前步骤: 无")
            
            # 更新按钮状态
            if status_copy['system'] == '已暂停':
                self.pause_btn.setText("恢复系统")
            else:
                self.pause_btn.setText("暂停系统")

        except Exception as e:
            self.logger.error(f"更新UI状态失败: {e}")
    

    
    def toggle_pause(self):
        """暂停/恢复系统"""
        # 使用全局变量引用对象
        # 切换暂停状态
        self.global_vars.paused = not self.global_vars.paused
        
        status = "暂停" if self.global_vars.paused else "恢复"
        self.logger.info(f"通过UI{status}系统")
        
        # 立即更新状态信息，不等待线程更新
        if self.global_vars.paused:
            self.status_info['system'] = '已暂停'
            self.pause_btn.setText("恢复系统")
        else:
            self.status_info['system'] = '运行中'
            self.pause_btn.setText("暂停系统")
            
        # 如果正在记录数据，更新记录状态
        if self.global_vars.is_recording:
            if self.global_vars.paused:
                self.status_info['recording'] = '已暂停'
                self.logger.info("数据记录已暂停")
            else:
                self.status_info['recording'] = '记录中'
                self.logger.info("数据记录已恢复")
    
    def motor_on(self):
        """开启电机"""
        try:
            # 检查电机连接状态，但不重新初始化
            if not self.motor.connected:
                self.logger.error("电机未连接，请确保系统已正常启动")
                return
                
            speed = round(self.speed_input.value(), 2) # Here is the first bug, you need to cut the command to ensure you send the correct one, edited by Kaiwen Fang
            # 修正方向逻辑：正转=0，反转=1
            direction = 0 if self.direction_input.currentText() == "正转" else 1
            
            # 直接发送开启命令，不再尝试重新初始化
            if self.motor.turn_on(speed, direction):
                self.logger.info(f"电机启动成功（匀速），速度：{speed}Hz，方向：{'反转' if direction else '正转'}")
            else:
                self.logger.error("电机启动失败")
        except Exception as e:
            self.logger.error(f"电机启动出错: {e}")
             
    def motor_on_biansu(self):
        """开启电机（变速）"""
        try:                
            speed = round(self.speed_input.value(), 2)
            # 修正方向逻辑：正转=0，反转=1
            direction = 0 if self.direction_input.currentText() == "正转" else 1
            
            # 直接发送开启命令，不再尝试重新初始化
            # if self.motor.step_180(speed, direction):
            if self.motor.step_180(speed, direction):
                self.logger.info(f"电机启动成功（步进半圈），速度：{speed}Hz，方向：{'反转' if direction else '正转'}")
            else:
                self.logger.error("电机启动失败")
        except Exception as e:
            self.logger.error(f"电机启动出错: {e}")
    
    def motor_home(self):
        """电机回零"""
        try:
            self.motor.run_to_home()
            self.logger.info("电机回零成功")
        except Exception as e:
            self.logger.error(f"电机回零出错: {e}")
    
    def motor_off(self):
        """关闭电机"""
        try:
            if self.motor.turn_off():
                self.logger.info("电机停止成功")
            else:
                self.logger.error("电机停止失败")
        except Exception as e:
            self.logger.error(f"电机停止出错: {e}")
    
    def start_actuation(self):
        """启动Actuation"""
        try:
            self.global_vars.actuation_running = True
            self.status_info['actuation'] = '运行中'
            self.logger.info("Actuation已启动")
            self.actuation_start_btn.setEnabled(False)
            self.actuation_stop_btn.setEnabled(True)
        except Exception as e:
            self.logger.error(f"启动Actuation出错: {e}")
    
    def stop_actuation(self):
        """停止Actuation"""
        try:
            self.global_vars.actuation_running = False
            self.status_info['actuation'] = '已停止'
            self.logger.info("Actuation已停止")
            self.actuation_start_btn.setEnabled(True)
            self.actuation_stop_btn.setEnabled(False)
        except Exception as e:
            self.logger.error(f"停止Actuation出错: {e}")
    
    def exit_program(self):
        """退出程序"""
        self.global_vars.running = False
        self.logger.info("用户通过UI退出程序")
        self.close()
        QApplication.quit()
        
    def toggle_recording(self):
        """切换录制状态（同时控制视频录制和轨迹绘制）"""
        # 使用全局变量引用对象
        self.global_vars.is_recording = not self.global_vars.is_recording
        
        if self.global_vars.is_recording:
            # 开始记录轨迹
            self.data_recorder.start_recording()
            
            # 开始录制视频
            frame_width = 2048
            frame_height = 2048
            video_success = self.data_recorder.start_video_recording(frame_width, frame_height)
            
            if video_success:
                self.status_info['recording'] = '记录中' if not self.global_vars.paused else '已暂停'
                self.record_btn.setText("停止录制（视频+轨迹）")
                self.logger.info("开始录制视频和轨迹")
            else:
                # 如果视频录制失败，也停止轨迹记录
                self.data_recorder.stop_recording()
                self.global_vars.is_recording = False
                self.logger.error("视频录制启动失败，已取消录制")
        else:
            # 停止记录轨迹
            self.data_recorder.stop_recording()
            
            # 停止录制视频
            self.data_recorder.stop_video_recording()
            
            self.status_info['recording'] = '未开始'
            self.record_btn.setText("开始录制（视频+轨迹）")
            self.logger.info("停止录制视频和轨迹")
    
    def clear_trajectory(self):
        """清除轨迹"""
        try:
            self.data_recorder.clear_trajectory()
            self.logger.info("轨迹已清除")
        except Exception as e:
            self.logger.error(f"清除轨迹失败: {e}")
    

    
    def save_data(self):
        """保存记录的数据"""
        try:
            if self.data_recorder.save():
                self.logger.info(f"数据已保存到: {self.data_recorder.file_path}")
            else:
                self.logger.warning("没有数据可保存")
        except Exception as e:
            self.logger.error(f"保存数据失败: {e}")
    
    def start_sequence(self):
        """启动控制序列"""
        try:
            self.global_vars.sequence_running = True
            self.logger.info("控制序列已启动")
        except Exception as e:
            self.logger.error(f"启动控制序列失败: {e}")
    
    def stop_sequence(self):
        """停止控制序列"""
        try:
            self.global_vars.sequence_running = False
            self.logger.info("控制序列已停止")
        except Exception as e:
            self.logger.error(f"停止控制序列失败: {e}")
            
    
    @pyqtSlot(np.ndarray)
    def update_raw_image(self, image):
        """更新原始图像显示"""
        try:
            # 将OpenCV图像转换为Qt图像
            height, width = image.shape
            bytes_per_line = width
            # 对于灰度图像，直接使用Format_Grayscale8
            qt_image = QImage(image.data, width, height, bytes_per_line, QImage.Format_Grayscale8)
            # 创建QPixmap并设置到标签
            pixmap = QPixmap.fromImage(qt_image)
            # 根据标签大小缩放图像
            pixmap = pixmap.scaled(self.raw_image_label.width(), self.raw_image_label.height(), 
                                  Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.raw_image_label.setPixmap(pixmap)
        except Exception as e:
            self.logger.error(f"更新原始图像失败: {e}")
    
    @pyqtSlot(np.ndarray)
    def update_processed_image(self, image):
        """更新处理后图像显示"""
        try:
            # 将OpenCV图像转换为Qt图像
            height, width, channel = image.shape
            bytes_per_line = 3 * width
            # OpenCV使用BGR格式，需要转换为RGB
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            qt_image = QImage(rgb_image.data, width, height, bytes_per_line, QImage.Format_RGB888)
            # 创建QPixmap并设置到标签
            pixmap = QPixmap.fromImage(qt_image)
            # 根据标签大小缩放图像
            pixmap = pixmap.scaled(self.processed_image_label.width(), self.processed_image_label.height(), 
                                  Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.processed_image_label.setPixmap(pixmap)
        except Exception as e:
            self.logger.error(f"更新处理后图像失败: {e}")