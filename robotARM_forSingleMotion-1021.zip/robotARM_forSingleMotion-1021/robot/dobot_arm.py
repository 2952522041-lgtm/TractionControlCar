"""
机械臂控制模块

本模块封装了与Dobot机械臂通信的所有功能，包括连接、初始化、
发送移动指令、获取位姿信息和资源释放等。

主要功能：
1. 建立与机械臂的TCP/IP连接
2. 初始化机械臂参数
3. 发送MovL指令控制机械臂移动
4. 获取机械臂当前位姿
5. 检查机械臂是否到达目标位置
6. 安全释放机械臂资源
"""

import time
import socket
import logging
# from main import cc
class DobotArm:
    """
    机械臂控制类
    
    封装了与Dobot机械臂通信的所有功能，包括连接、初始化、
    发送移动指令、获取位姿信息和资源释放等。
    
    属性:
        ip (str): 机械臂IP地址
        ports (list): 机械臂通信端口列表 [控制端口, 实时状态端口, 反馈端口]
        sockets (dict): 存储与机械臂各端口连接的套接字
        connected (bool): 是否已连接到机械臂
        logger (Logger): 日志记录器
    """
    
    def __init__(self, ip, ports, logger=None):
        """
        初始化机械臂连接
        
        参数:
            ip (str): 机械臂IP地址
            ports (list): 机械臂通信端口列表 [控制端口, 实时状态端口, 反馈端口]
            logger (Logger, optional): 日志记录器，如果为None则创建一个新的
        """
        self.ip = ip
        self.ports = ports
        self.sockets = {}
        self.connected = False
        self.logger = logger or logging.getLogger(__name__)
        
    def connect(self):
        """
        建立与机械臂的连接
        
        尝试连接到机械臂的所有指定端口。
        
        返回:
            bool: 连接是否成功
        
        异常:
            记录连接过程中的任何异常
        """
        try:
            for port in self.ports:
                self.sockets[port] = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sockets[port].connect((self.ip, port))
            self.connected = True
            return True
        except Exception as e:
            
            # 修改后
            self.logger.error(f"连接机械臂失败: {e}")
            self.connected = False
            return False
    
    def initialize(self):
        """
        机械臂初始化
        
        发送一系列命令初始化机械臂，包括设置速度、碰撞等级、负载和使能机械臂。
        
        返回:
            bool: 初始化是否成功
            
        异常:
            记录初始化过程中的任何异常
        """
        if not self.connected:
            self.logger.error("机械臂未连接，请先连接")
            return False
            
        init_commands = [
            b'SpeedL(100)',
            b'SetCollisionLevel(1)',
            b'PayLoad(3,1)',
            b'User(1)',
            # b'Tool(2)',#145
            b'Tool(1)',#139
            b'EnableRobot()'
        ]
        
        try:
            for cmd in init_commands[:-1]:
                self.sockets[29999].send(cmd)
                _ = self.sockets[29999].recv(100)
                time.sleep(0.001)
            # 最后一个命令等待较长时间
            self.sockets[29999].send(init_commands[-1])
            _ = self.sockets[29999].recv(100)
            time.sleep(3)
            return True
        except Exception as e:
            self.logger.error(f"机械臂初始化失败: {e}")
            return False
    
    def cleanup(self):
        if not self.connected:
            return
            
        try:
            # 先停止运动
            self.stop_motion()
            # 下使能
            self.sockets[29999].send(b'DisableRobot()')
            _ = self.sockets[29999].recv(100)
            
            # 关闭所有 socket
            for port, sock in self.sockets.items():
                try:
                    sock.close()
                except Exception as e:
                    self.logger.error(f"关闭端口 {port} 失败: {e}")
            self.logger.info(f"关闭端口29999、30003、30004的连接")
            self.connected = False
            self.logger.info("机械臂资源已完全释放")
        except Exception as e:
            self.logger.error(f"机械臂清理资源失败: {e}")
    
    def close(self):
        """
        关闭与机械臂的连接
        
        先下使能机械臂，然后关闭所有套接字连接。
        """
        self.cleanup()
        for s in self.sockets.values():
            try:
                s.close()
            except:
                pass
        self.connected = False
    
    def get_flange_pose(self):
        """
        获取法兰盘在世界坐标系下的位姿
        
        发送GetPose命令获取机械臂当前位姿。
        
        返回:
            tuple or None: 如果成功，返回位姿元组 (x, y, z, rx, ry, rz)，否则返回None
            
        异常:
            记录获取位姿过程中的任何异常
        """
        if not self.connected:
            return None
            
        try:
            self.sockets[30003].send(b'GetPose()')
            data = self.sockets[30003].recv(100)
            flange_pose = self._extract_coordinates(data)
            return flange_pose
        except Exception as e:
            self.logger.error(f"获取法兰盘位姿失败: {e}")
            return None
    
    def send_movL_command(self, TARGET_POSE, SPEED=1):
        """
        发送MovL指令移动机械臂
        """
        if not self.connected:
            return False
            
        try:
            x, y, z, rx, ry, rz = (round(val, 2) for val in TARGET_POSE)
            command = f'MovL({x},{y},{z},{rx},{ry},{rz},SpeedL={SPEED})'
            com = command.encode('utf-8')
    
            # 发送移动命令
            self.sockets[30003].send(com)
            _ = self.sockets[30003].recv(100)
            return True
        except Exception as e:
            self.logger.error(f"发送MovL命令失败: {e}")
            return False

    def send_RelMovLUser_command(self, dz):
        """在用户坐标系下增量方式移动z"""
        if not self.connected:
            return False
        try:
            command = f'RelMovLUser(0,0,{dz},0,0,0,SpeedL=1)'
            com = command.encode('utf-8')
    
            # 发送移动命令
            self.sockets[30003].send(com)
            _ = self.sockets[30003].recv(100)
            return True
        except Exception as e:
            self.logger.error(f"发送RelMovLUser命令失败: {e}")
            return False

    def send_RelMovLTool_command(self, dx):
        """在工具坐标系下增量方式移动dy"""
        if not self.connected:
            return False
            
        try:
            command = f'RelMovLTool({dx},0,0,0,0,0,SpeedL=1)'
            com = command.encode('utf-8')
    
            # 发送移动命令
            self.sockets[30003].send(com)
            _ = self.sockets[30003].recv(100)
            return True
        except Exception as e:
            self.logger.error(f"发送RelMovLTool命令失败: {e}")
            return False
    
    def check_if_reached(self, target_pose, tolerance=1.0):
        """
        检查机械臂是否到达目标位置
        """
        if not self.connected:
            return False
            
        try:
            current_pose = self.get_flange_pose()
            x = current_pose[0]
            y = current_pose[1]
            rz=current_pose[5]
            if current_pose is None:
                return False
                
            # 只检查位置，不检查姿态
            if(abs(target_pose[0]-x)<2 and
               abs(target_pose[1]-y)<2 and
               abs(target_pose[5]-rz)<2):
                return True

        except Exception as e:
            self.logger.error(f"检查位置到达失败: {e}")
            return False
    
    def _extract_coordinates(self, data):
        """
        从返回的字节数据中提取坐标信息
        
        解析机械臂返回的数据，提取位姿信息。
        
        参数:
            data (bytes): 机械臂返回的原始数据
            
        返回:
            tuple or None: 如果成功，返回位姿元组 (x, y, z, rx, ry, rz)，否则返回None
            
        异常:
            记录数据解析过程中的任何异常
        """
        try:
            data_str = data.decode('utf-8')
            start = data_str.find('{') + 1
            end = data_str.find('}', start)
            if start == 0 or end == -1:
                return None
            values = data_str[start:end].split(',')
            if len(values) < 6:
                return None
            # 提取世界坐标系中的坐标
            x, y, z, rx, ry, rz = (round(float(val), 2) for val in values[:6])
            return x, y, z, rx, ry, rz

        except Exception as e:
            print(f"坐标提取错误: {e}")
            return None

    def stop_motion(self):
        """
        停止机械臂运动
        
        发送停止运动的命令给机械臂。
        
        返回:
            bool: 命令是否成功发送
        """
        if not self.connected:
            return False
            
        try:
            self.sockets[30003].send(b'StopMotion()')
            _ = self.sockets[30003].recv(100)
            self.logger.info("机械臂运动已停止")
            return True
        except Exception as e:
            self.logger.error(f"停止机械臂运动失败: {e}")
            return False
    
    def down(self, distance_mm):
        """
        机械臂下降指定距离
        """
        try:
            self.send_RelMovLUser_command(-distance_mm)
            self.logger.info(f"机械臂下降{distance_mm}mm")
            return True
        except Exception as e:
            self.logger.error(f"机械臂下降失败: {e}")
            return False