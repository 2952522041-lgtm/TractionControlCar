import time
import serial
import logging
from threading import Timer


class Motor:
    """
    电机控制类
    
    封装了与电机通信的所有功能，包括串口连接、初始化、
    发送控制命令和资源释放等。
    
    属性:
        port (str): 串口名称
        baud_rate (int): 波特率
        timeout (float): 超时时间
        ser (Serial): 串口对象
        connected (bool): 是否已连接到电机
        logger (Logger): 日志记录器
    """
    
    def __init__(self, port, baud_rate, timeout=0.1, logger=None):
        """
        初始化电机连接
        
        参数:
            port (str): 串口名称
            baud_rate (int): 波特率
            timeout (float): 超时时间，默认0.1秒
            logger (Logger, optional): 日志记录器，如果为None则创建一个新的
        """
        self.port = port
        self.baud_rate = baud_rate
        self.timeout = timeout
        self.connected = False
        self.logger = logger or logging.getLogger(__name__)
        self.current_speed = 0  # 添加当前转速属性
        self.current_direction = 0  # 添加当前方向属性
        self._last_flag = False  # 上次窗口期状态，默认 False（非窗口）
        self._dongting = False
        
    def connect(self):
        """
        建立与电机的连接
        
        尝试打开指定的串口连接电机。
        
        返回:
            bool: 连接是否成功
            
        异常:
            记录连接过程中的任何异常
        """
        try:
            self.ser = serial.Serial(self.port, self.baud_rate, timeout=self.timeout)
            self.connected = True
            return True
        except Exception as e:
            self.logger.error(f"连接电机失败: {e}")  
            self.connected = False
            return False
    
    def initialize(self):
        """
        电机初始化
        
        等待串口接收 'S'，收到后发送 'R' 完成电机初始化。
        
        返回:
            bool: 初始化是否成功
            
        异常:
            记录初始化过程中的任何异常
        """
        if not self.connected:
            self.logger.error("电机未连接，请先连接")
            return False
            
        try:
            # 清空串口缓冲区
            if self.ser.in_waiting:
                self.ser.reset_input_buffer()
                self.ser.reset_output_buffer()
                
            timeout_start = time.time()
            while time.time() - timeout_start < 10:  # 10秒超时
                if self.ser.in_waiting > 0:
                    incoming = self.ser.read(1)
                    self.logger.debug(f"接收到数据: {incoming}")
                    if incoming == b'S':
                        self.logger.info("接收到 'S'，发送 'R'")
                        self.ser.write(b'R')
                        self.logger.info("初始化命令'R'已发送")
                        time.sleep(0.1)
                        # self.run_to_home()

                        return True
                    else:
                        self.logger.debug(f"接收到未知数据: {incoming}")
                time.sleep(0.1)
            self.logger.error("电机初始化超时")

            self.logger.info("电机已回零")
            return True
        except Exception as e:
            self.logger.error(f"电机初始化失败: {e}")
            return False
    
    def send_command(self, command):
        """
        发送电机命令
        
        发送命令到电机并等待含 'R' 的响应返回。
        
        参数:
            command (str or bytes): 要发送的命令
            
        返回:
            str or None: 如果成功，返回电机的响应，否则返回None
            
        异常:
            记录发送命令过程中的任何异常
        """
            
        try:
            encoded_command = command.encode() if isinstance(command, str) else command
            timeout = 5
            end_time = time.time() + float(timeout)
            self.ser.write(encoded_command)  
            # initial_time = time.time()
            # while time.time() < end_time:
            #     if self.ser.in_waiting: # Here is the second bug, it spends too long time to read the response, but I didn't find the reason
            #         response = self.ser.read(self.ser.in_waiting).decode()
            #         if 'R' in response:
            #             return response
            #     else:
            #         # print(time.time()-initial_time)  #display waiting time, edited by Kaiwen Fang
            #         return None
        except Exception as e:
            self.logger.error(f"发送电机命令失败: {e}")
            return None
    
    
    def turn_on(self, speed=5, direction=0):
        """
        开启电机
        
        发送开启电机的命令。
        
        参数:
            speed (float): 电机转速，单位为赫兹，默认为5
            direction (int): 旋转方向，0表示正转，1表示反转，默认为0
            
        返回:
            bool: 命令是否成功发送
        """
        try:
            command = f'R{speed},{direction}'
            _ = self.send_command(command)
            self.current_speed = speed
            self.current_direction = direction
            self.logger.info(f"电机已开启，转速: {speed}Hz，方向: {'反转' if direction else '正转'}")
            return True
        except Exception as e:
            self.logger.error(f"开启电机失败: {e}")
            return False
        
        
    def turn_on_biansu(self, speed=5, direction=0, angle = 90):
        """
        开启电机，变速，返回布尔变量
        """
        try:
            command = f'D{speed},{direction},{angle}'
            _ = self.send_command(command)
            self.current_speed = speed
            self.current_direction = direction
            self.logger.info(f"电机已开启（变速），转速: {speed}Hz，方向: {'反转' if direction else '正转'}，角度: {angle}")
            return True
        except Exception as e:
            self.logger.error(f"开启电机失败: {e}")
            return False
        
    def step(self, speed: float =5, direction=0, angle=90):
        """电机步进特定角度"""
        self.send_command(f'D{speed},{direction},{angle}')
        self.current_speed, self.current_direction = speed, direction
        self.logger.info(f'电机步进{angle}°')
        return True

    def read_byte_with_polling(self, timeout=2.0):
        """
        在 timeout 秒内每 10ms 检查一次：
        如果 ser.in_waiting > 0 ，则马上读走一个字节返回；
        如果超时仍无数据，则返回 b''。
        """
        start = time.time()
        while time.time() - start < timeout:
            if self.ser.in_waiting > 0:           # 有字节可读
                return self.ser.read(1)           # 立即读一个字节
            time.sleep(0.01)                 # 小休眠，避免 100% 占用 CPU
        return b''  # 超时未读到

    def poll_ack(self):
        """
        轮询串口：如果最新字节是 'A' 就把速度清零并返回 True。
        非阻塞，可放在主循环里反复调用。
        """
        
        buf = self.read_byte_with_polling()
        # print('buf= ',buf)
        if buf == b'A':
            self._dongting = True
        if buf == b'B':
            self._dongting = False
        return self._dongting


    def is_in_window(self):
        """
        读取串口缓存里的最新 T/F：有新字节就更新 _last_flag，
        否则返回上次保存的状态。
        """

        n = self.ser.in_waiting
        if n:
            buf = self.ser.read(n)

            if buf == b'T':
                self._last_flag = True
            if buf == b'F':
                self._last_flag = False
        return self._last_flag

    def turn_off(self):
        """
        关闭电机
        
        发送关闭电机的命令。
        
        返回:
            bool: 命令是否成功发送
        """
        try:
            result = self.send_command('P')
            if result is not None:
                self.current_speed = 0
                self.current_direction = 0
            self.logger.info("电机已关闭")
            return result is not None
        except Exception as e:
            self.logger.error(f"关闭电机失败: {e}")
            return False
    
    def get_current_speed(self):
        """
        获取当前电机转速
        
        返回:
            float: 当前电机转速(Hz)
        """
        return self.current_speed
    
    def run_to_home(self):
        """电机回零操作，回到设定的原点"""
        
        self.send_command('H')
        time.sleep(0.5)
        self.logger.info("电机已回零")
        
        return True
    
    def cleanup(self):
        """
        清理电机资源
        
        关闭电机并释放串口资源。
        """
        try:
            if self.connected:
                self.turn_off()  # 先关闭电机
                if self.ser and self.ser.is_open:
                    self.ser.close()
                    self.connected = False
                    self.logger.info("电机串口已关闭")
        except Exception as e:
            self.logger.error(f"清理电机资源失败: {e}")
        if self.ser:
            try:
                self.ser.close()
            except:
                pass
        self.connected = False