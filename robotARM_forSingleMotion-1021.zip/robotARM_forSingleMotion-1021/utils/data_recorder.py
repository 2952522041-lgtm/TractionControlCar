"""数据记录模块

本模块提供数据记录功能，将视觉识别的物体信息和电机参数
记录到Excel文件中，便于后续分析和处理。同时支持轨迹绘制功能和视频录制功能。

主要功能：
1. 创建Excel文件并设置表头
2. 记录电机转速、物体坐标和朝向
3. 定时保存数据到文件
4. 提供轨迹点数据用于绘制
5. 双视频流录制功能（同时录制原始视频和处理后视频）
"""

import os
import time
import pandas as pd
import cv2
from datetime import datetime

class DataRecorder:
    """数据记录器类，负责记录和管理实验数据"""
    
    def __init__(self):
        """初始化数据记录器"""
        self.data = []  # 记录的数据列表
        self.columns = [
            'rotating_freq(Hz)', 
            'X', 
            'Y', 
            'X_filtered', 
            'Y_filtered', 
            'orient(deg)',
            'alpha0(deg)',     
            'delta_alpha(deg)',
            'psi_v(deg)',      
            'PID_error(deg)',
            'alpha_cmd(deg)',
            'psi_v_hat(deg)',  # 新增ESO观测速度方向
            'distur_hat',      # 新增扰动估计
            'eso_comp_deg(deg)', # 新增ESO补偿角度
            'alpha_cmd_eso_deg(deg)', # 新增ESO补偿后角度命令
            'signed_dist(px)', # 新增到轨迹的有向距离
            't(s)'
        ]
        self.file_path = None
        self.auto_save = True
        self.save_interval = 30
        self.last_save_time = time.time()
        self.logger = None
        self.start_time = None
        self.is_recording = False
        self.trajectory_points = []  # 存储轨迹点
        self.video_writer_processed = None
        self.video_writer_raw = None
        self.is_recording_video = False
        self.video_path_processed = None
        self.video_path_raw = None
        self.output_dir = None
    
    def initialize(self, output_dir=None, filename=None, auto_save_enabled=True, 
                  save_interval_seconds=30, logger=None):
        """
        初始化数据记录器
        
        参数:
            output_dir (str, optional): 输出目录，默认为当前目录下的data文件夹
            filename (str, optional): 文件名，默认为当前日期时间
            auto_save_enabled (bool, optional): 是否自动保存，默认为True
            save_interval_seconds (int, optional): 自动保存间隔（秒），默认为30秒
            logger (Logger, optional): 日志记录器，如果为None则使用print
        """
        # 设置输出目录
        if output_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            output_dir = os.path.join(base_dir, 'data')
        
        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)
        self.output_dir = output_dir
        
        # 设置文件名
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"vision_data_{timestamp}.xlsx"
        
        self.file_path = os.path.join(output_dir, filename)
        self.auto_save = auto_save_enabled
        self.save_interval = save_interval_seconds
        self.logger = logger
        
        self._log_info(f"数据记录器已初始化，输出文件: {self.file_path}")
    
    def start_recording(self):
        """开始记录数据和轨迹"""
        # 清空之前的数据
        self.data = []
        self.trajectory_points = []
        
        self.start_time = time.time()
        self.is_recording = True
        self._log_info("开始记录数据和轨迹")
        return True
    
    def stop_recording(self):
        """停止记录数据和轨迹"""
        if self.is_recording:
            self.is_recording = False
            self._log_info("停止记录数据和轨迹")
            # 自动保存数据
            self.save()
        return True
    
    def add_record(self, motor_speed, center_x, center_y, orientation, 
                  alpha0, delta_alpha, psi_v, pid_error, alpha_cmd=0.0, psi_v_hat=0.0, distur_hat=0.0, 
                  eso_comp_deg=0.0, alpha_cmd_eso_deg=0.0, signed_dist=0.0, filtered_x=None, filtered_y=None):  # 添加滤波后坐标参数
        """
        添加一条记录
        
        参数:
            motor_speed (float): 电机转速(Hz)
            center_x (float): 物体中心X坐标
            center_y (float): 物体中心Y坐标
            orientation (float): 物体朝向(deg)
            alpha0 (float): 初始角度(deg)
            delta_alpha (float): 角度补偿(deg)
            psi_v (float): 速度方向(deg)
            pid_error (float): PID误差值(deg)
            alpha_cmd (float): 角度命令(deg)
            psi_v_hat (float): ESO观测速度方向(deg)
            distur_hat (float): ESO扰动估计
            eso_comp_deg (float): ESO补偿角度(deg)
            alpha_cmd_eso_deg (float): ESO补偿后角度命令(deg)
            signed_dist (float): 到轨迹的有向距离(px)
            filtered_x (float, optional): 滤波后的X坐标
            filtered_y (float, optional): 滤波后的Y坐标
        """
        if not self.is_recording:
            return
        
        # 计算当前时间（相对于开始时间）
        current_time = 0.0
        if self.start_time is not None:
            current_time = round(time.time() - self.start_time, 2)  # 保留两位小数
        
        # 如果滤波后的坐标为None，则使用原始坐标
        if filtered_x is None:
            filtered_x = center_x
        if filtered_y is None:
            filtered_y = center_y
            
        # 添加数据记录
        record = [
            motor_speed, 
            center_x, 
            center_y, 
            filtered_x,       # 添加滤波后的X坐标
            filtered_y,       # 添加滤波后的Y坐标
            orientation,
            alpha0,          
            delta_alpha,      
            psi_v,            
            pid_error,        
            alpha_cmd,
            psi_v_hat,        # 添加ESO观测速度方向
            distur_hat,       # 添加ESO扰动估计
            eso_comp_deg,     # 添加ESO补偿角度
            alpha_cmd_eso_deg, # 添加ESO补偿后角度命令
            signed_dist,      # 添加到轨迹的有向距离
            current_time
        ]
        self.data.append(record)
        
        # 添加轨迹点
        self.trajectory_points.append((center_x, center_y))
        
        # 如果启用了自动保存，检查是否需要保存
        if self.auto_save and (time.time() - self.last_save_time) > self.save_interval:
            self.save()
    
    def save(self):
        """保存数据到Excel文件"""
        try:
            df = pd.DataFrame(self.data, columns=self.columns)
            df.to_excel(self.file_path, index=False)
            self.last_save_time = time.time()
            self._log_info(f"数据已保存到 {self.file_path}，共 {len(self.data)} 条记录")
            return True
        except Exception as e:
            self._log_error(f"保存数据失败: {e}")
            return False
    
    def clear(self):
        """清空数据和轨迹"""
        self.data = []
        self.trajectory_points = []
        self._log_info("数据和轨迹已清空")
    
    def clear_trajectory(self):
        """清除轨迹"""
        self.trajectory_points = []
        self._log_info("轨迹已清除")
    
    def get_trajectory_points(self):
        """获取轨迹点列表"""
        return self.trajectory_points
        
    def start_video_recording(self, frame_width, frame_height, fps=20.0):
        """开始录制视频（同时录制原始和处理后的视频）
        
        参数:
            frame_width (int): 视频帧宽度
            frame_height (int): 视频帧高度
            fps (float): 视频帧率
        """
        if self.is_recording_video:
            self._log_info("视频已经在录制中")
            return True
            
        try:
            # 使用与Excel相同的时间戳命名视频文件
            if self.file_path:
                # 从Excel文件路径提取基本文件名
                base_filename = os.path.splitext(os.path.basename(self.file_path))[0]
                video_filename_processed = f"{base_filename}_processed.mp4"
                video_filename_raw = f"{base_filename}_raw.mp4"
                self.video_path_processed = os.path.join(self.output_dir, video_filename_processed)
                self.video_path_raw = os.path.join(self.output_dir, video_filename_raw)
            else:
                # 如果没有Excel文件路径，创建新的时间戳
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                video_filename_processed = f"vision_video_{timestamp}_processed.mp4"
                video_filename_raw = f"vision_video_{timestamp}_raw.mp4"
                self.video_path_processed = os.path.join(self.output_dir, video_filename_processed)
                self.video_path_raw = os.path.join(self.output_dir, video_filename_raw)
            
            # 创建VideoWriter对象
            fourcc = cv2.VideoWriter_fourcc(*'avc1')
            
            # 创建处理后视频的写入器（彩色）
            self.video_writer_processed = cv2.VideoWriter(self.video_path_processed, fourcc, fps, (frame_width, frame_height), True)
            
            # 创建原始视频的写入器（灰度，需要转换为彩色格式）
            self.video_writer_raw = cv2.VideoWriter(self.video_path_raw, fourcc, fps, (frame_width, frame_height), True)
            
            if not self.video_writer_processed.isOpened():
                self._log_error(f"无法创建处理后视频文件: {self.video_path_processed}")
                return False
                
            if not self.video_writer_raw.isOpened():
                self._log_error(f"无法创建原始视频文件: {self.video_path_raw}")
                # 清理已创建的处理后视频写入器
                self.video_writer_processed.release()
                self.video_writer_processed = None
                return False
                
            self.is_recording_video = True
            self._log_info(f"开始录制视频: 处理后={self.video_path_processed}, 原始={self.video_path_raw}")
            return True
        except Exception as e:
            self._log_error(f"开始视频录制失败: {e}")
            return False
    
    def stop_video_recording(self):
        """停止录制视频（同时停止两个视频录制器）"""
        if not self.is_recording_video:
            self._log_info("当前没有在录制视频")
            return True
            
        try:
            # 停止处理后视频录制
            if self.video_writer_processed:
                self.video_writer_processed.release()
                self.video_writer_processed = None
                
            # 停止原始视频录制
            if self.video_writer_raw:
                self.video_writer_raw.release()
                self.video_writer_raw = None
                
            self.is_recording_video = False
            self._log_info(f"视频录制已停止，文件保存至: 处理后={self.video_path_processed}, 原始={self.video_path_raw}")
            return True
        except Exception as e:
            self._log_error(f"停止视频录制失败: {e}")
            return False
    
    def write_video_frame(self, processed_frame, raw_frame=None):
        """写入视频帧（同时写入处理后和原始帧）
        
        参数:
            processed_frame: 处理后的视频帧（numpy数组）
            raw_frame: 原始视频帧（numpy数组，可选）
        """
        if not self.is_recording_video:
            return False
            
        try:
            success = True
            
            # 写入处理后的帧
            if self.video_writer_processed is not None:
                if len(processed_frame.shape) == 3 and processed_frame.shape[2] == 3:
                    # BGR格式，直接写入
                    self.video_writer_processed.write(processed_frame)
                elif len(processed_frame.shape) == 2:
                    # 灰度图，转换为BGR
                    frame_bgr = cv2.cvtColor(processed_frame, cv2.COLOR_GRAY2BGR)
                    self.video_writer_processed.write(frame_bgr)
                else:
                    self._log_error(f"不支持的处理后帧格式: {processed_frame.shape}")
                    success = False
            
            # 写入原始帧（如果提供）
            if raw_frame is not None and self.video_writer_raw is not None:
                if len(raw_frame.shape) == 3 and raw_frame.shape[2] == 3:
                    # BGR格式，直接写入
                    self.video_writer_raw.write(raw_frame)
                elif len(raw_frame.shape) == 2:
                    # 灰度图，转换为BGR
                    frame_bgr = cv2.cvtColor(raw_frame, cv2.COLOR_GRAY2BGR)
                    self.video_writer_raw.write(frame_bgr)
                else:
                    self._log_error(f"不支持的原始帧格式: {raw_frame.shape}")
                    success = False
                    
            return success
        except Exception as e:
            self._log_error(f"写入视频帧失败: {e}")
            return False
    
    def _log_info(self, message):
        """记录信息"""
        if self.logger:
            self.logger.info(message)
        else:
            print(message)
    
    def _log_error(self, message):
        """记录错误"""
        if self.logger:
            self.logger.error(message)
        else:
            print(f"错误: {message}")

# 创建全局实例，保持与原模块兼容的接口
_instance = DataRecorder()

# 为了保持与原模块兼容的接口，提供以下函数
def initialize(output_dir=None, filename=None, auto_save_enabled=True, 
              save_interval_seconds=30, logger=None):
    return _instance.initialize(output_dir, filename, auto_save_enabled, 
                               save_interval_seconds, logger)

def start_recording():
    return _instance.start_recording()

def stop_recording():
    return _instance.stop_recording()

def add_record(motor_speed, center_x, center_y, orientation, alpha0=0.0, delta_alpha=0.0, psi_v=0.0, pid_error=0.0, alpha_cmd=0.0, psi_v_hat=0.0, distur_hat=0.0, eso_comp_deg=0.0, alpha_cmd_eso_deg=0.0, signed_dist=0.0):
    return _instance.add_record(motor_speed, center_x, center_y, orientation, alpha0, delta_alpha, psi_v, pid_error, alpha_cmd, psi_v_hat, distur_hat, eso_comp_deg, alpha_cmd_eso_deg, signed_dist)

def save():
    return _instance.save()

def clear():
    return _instance.clear()

def clear_trajectory():
    return _instance.clear_trajectory()

def get_trajectory_points():
    return _instance.get_trajectory_points()

# 视频录制相关函数
def start_video_recording(frame_width, frame_height, fps=20.0):
    return _instance.start_video_recording(frame_width, frame_height, fps)

def stop_video_recording():
    return _instance.stop_video_recording()

def write_video_frame(processed_frame, raw_frame=None):
    return _instance.write_video_frame(processed_frame, raw_frame)

def is_recording_video():
    return _instance.is_recording_video