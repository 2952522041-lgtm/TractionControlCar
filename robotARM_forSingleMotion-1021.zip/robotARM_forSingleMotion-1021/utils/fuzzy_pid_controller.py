# fuzzy_pid_controller.py

import numpy as np

# ===================================
# 工具函数（隶属函数与解模糊）
# ===================================

def trimf(x, abc):
    a, b, c = abc
    y = np.zeros_like(x)
    idx1 = (a < x) & (x <= b)
    idx2 = (b < x) & (x < c)
    y[idx1] = (x[idx1] - a) / (b - a)
    y[idx2] = (c - x[idx2]) / (c - b)
    y[x == b] = 1.0
    return y

def defuzzify(x_range, mfs, agg_output):
    μ_agg = np.zeros_like(x_range)
    for label, μ in agg_output.items():
        μ_agg = np.fmax(μ_agg, μ * mfs[label])
    numerator = np.sum(x_range * μ_agg)
    denominator = np.sum(μ_agg)
    return 0.0 if denominator == 0 else numerator / denominator

# ===================================
# 模糊逻辑控制器
# ===================================

class FuzzyLogicController:
    def __init__(self):
        self.labels = ["NB", "NS", "ZO", "PS", "PB"]
        self.x_range = np.linspace(-1, 1, 100)

        self.input_mfs = {
            label: trimf(self.x_range, points)
            for label, points in {
                "NB": [-1.0, -1.0, -0.5],
                "NS": [-1.0, -0.5, 0.0],
                "ZO": [-0.5, 0.0, 0.5],
                "PS": [0.0, 0.5, 1.0],
                "PB": [0.5, 1.0, 1.0]
            }.items()
        }

        self.output_sets = self.input_mfs

        self.rules_kp = self._load_kp_rules()
        self.rules_ki = self._load_ki_rules()
        self.rules_kd = self._load_kd_rules()

    def _load_kp_rules(self):
        return [
            ["PB", "PB", "PB", "PS", "ZO"],
            ["PB", "PS", "PS", "ZO", "NS"],
            ["PS", "ZO", "ZO", "ZO", "NS"],
            ["PS", "ZO", "NS", "NS", "NB"],
            ["ZO", "NS", "NS", "NB", "NB"]
        ]

    def _load_ki_rules(self):
        return [
            ["NS", "ZO", "PS", "PS", "PB"],
            ["NS", "ZO", "ZO", "PS", "PS"],
            ["NB", "NS", "ZO", "NS", "NB"],
            ["NS", "ZO", "ZO", "ZO", "NS"],
            ["PB", "PS", "PS", "ZO", "NS"]
        ]

    def _load_kd_rules(self):
        return [
            ["NB", "NS", "ZO", "PS", "PS"],
            ["NB", "NS", "ZO", "PS", "PB"],
            ["NS", "NS", "ZO", "NS", "NS"],
            ["NS", "NS", "ZO", "PS", "PB"],
            ["PS", "PS", "ZO", "NS", "NB"]
        ]

    def _fuzzify(self, val):
        return {
            label: np.interp(val, self.x_range, mf)
            for label, mf in self.input_mfs.items()
        }

    def _infer(self, μ_e, μ_de, rule_table):
        aggregated = {label: 0.0 for label in self.labels}
        for i, e_label in enumerate(self.labels):
            for j, de_label in enumerate(self.labels):
                output_label = rule_table[i][j]
                strength = min(μ_e[e_label], μ_de[de_label])
                aggregated[output_label] = max(aggregated[output_label], strength)
        return aggregated

    def compute(self, e_theta, de_theta):
        μ_e = self._fuzzify(e_theta)
        μ_de = self._fuzzify(de_theta)

        agg_kp = self._infer(μ_e, μ_de, self.rules_kp)
        agg_ki = self._infer(μ_e, μ_de, self.rules_ki)
        agg_kd = self._infer(μ_e, μ_de, self.rules_kd)

        dkp = defuzzify(self.x_range, self.output_sets, agg_kp)
        dki = defuzzify(self.x_range, self.output_sets, agg_ki)
        dkd = defuzzify(self.x_range, self.output_sets, agg_kd)

        return dkp, dki, dkd

# ===================================
# PID 控制器封装
# ===================================

class FuzzyAdaptivePID:
    def __init__(self, kp_base, ki_base, kd_base, fuzzy_logic_controller, integrator_limit, dt):
        self.kp_base = kp_base
        self.ki_base = ki_base
        self.kd_base = kd_base
        self.fuzzy = fuzzy_logic_controller
        self.integral = 0.0
        self.prev_error = 0.0
        self.integrator_limit = integrator_limit
        self.dt = dt
        
    def _normalize(self, val, xmin, xmax):
        return np.clip((val - xmin) / (xmax - xmin) * 2 - 1, -1, 1)
    
    def compute(self, setpoint: float, measurement: float) -> float:
        
        error = setpoint - measurement
        d_error = (error - self.prev_error) / self.dt

        e_norm = self._normalize(error, -90, 90)
        de_norm = self._normalize(d_error,-45, 45)
        dkp, dki, dkd = self.fuzzy.compute(e_norm, de_norm)

        # 裁剪 ΔKp/Ki/Kd
        dkp = np.clip(dkp, -0.8, 0.8)
        dki = np.clip(dki, -0.9, 0.9)
        dkd = np.clip(dkd, -0.7, 0.7)

        kp = self.kp_base * (1 + dkp)
        ki = self.ki_base * (1 + dki)
        kd = self.kd_base * (1 + dkd)

        self.integral += error * self.dt
        self.integral = np.clip(self.integral, -self.integrator_limit, self.integrator_limit)
        output = kp * error + ki * self.integral + kd * d_error

        self.prev_error = error
        return output