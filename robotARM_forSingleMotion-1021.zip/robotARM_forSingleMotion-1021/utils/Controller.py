from tkinter import Y
import numpy as np
import math
from utils.path import *
from scipy import ndimage as ndi

def bilinear_interpolate(arr, x: float, y: float) -> float:
    """在二维数组 arr 上对浮点坐标 (y, x) 进行双线性插值"""
    h, w = arr.shape
    # 四个整数格点
    x0 = int(np.floor(x))
    x1 = min(x0 + 1, w - 1)
    y0 = int(np.floor(y))
    y1 = min(y0 + 1, h - 1)
    # 插值权重
    dx = x - x0
    dy = y - y0
    # 四邻点值
    v00 = arr[y0, x0]
    v10 = arr[y0, x1]
    v01 = arr[y1, x0]
    v11 = arr[y1, x1]
    # 双线性插值公式
    return (
        v00 * (1 - dx) * (1 - dy) +
        v10 * dx * (1 - dy) +
        v01 * (1 - dx) * dy +
        v11 * dx * dy
    )

def calc_grad(Z: np.ndarray, cellsize: float = 1.0):
    """
    5×5 局部平面最小二乘近似 DEM 梯度。
    返回 dzdx, dzdy，与 Z 同形状。
    """
    coords = np.arange(-2, 3)
    qx = coords / (50 * cellsize)
    kernel_x = np.tile(qx, (5, 1))
    kernel_y = kernel_x.T
    dzdx = ndi.convolve(Z, kernel_x, mode="nearest")
    dzdy = ndi.convolve(Z, kernel_y, mode="nearest")
    return dzdx, dzdy

import numpy as np
import math

def calc_velocity_direction_sliding_window(coord_history, window_size=9, prev_angle = None):
    """
    使用滑动窗口法计算速度方向 (向量平均 or 圆统计中位)

    参数:
        coord_history: 坐标历史列表，按时间从新到旧排序 [(x0,y0), (x1,y1), ...]
        window_size: 滑动窗口大小
        method: "mean" 使用向量平均; "median" 使用圆统计中位

    返回:
        velocity_direction: 速度方向 (角度, 逆时针为正, 单位:度)
    """
    if len(coord_history) < window_size + 1:
        return 0.0
    # 取窗口
    window = coord_history[:window_size]
    # 计算窗口内相邻点的位移向量
    dx_list = []
    dy_list = []
    for i in range(len(window) - 1):
        dx = window[i+1][0] - window[i][0]
        dy = window[i+1][1] - window[i][1]
        dx_list.append(dx)
        dy_list.append(dy)
    dx_list = np.array(dx_list)
    dy_list = np.array(dy_list)
    # --- 向量平均 ---
    dx_mean = np.mean(dx_list)
    dy_mean = np.mean(dy_list)
    angle = math.atan2(dy_mean, dx_mean)
   
    # 转换为角度制，并调整方向
    angle_deg = -np.rad2deg(angle)
    
    # # 角度解缠绕：调整当前角度以确保与前一角度连续
    # if prev_angle is not None:
    #     # 计算角度差，并调整到[-180, 180]范围
    #     angle_diff = angle_deg - prev_angle
    #     angle_diff = (angle_diff + 180) % 360 - 180
    #     angle_deg = prev_angle + angle_diff
    # else:
    #     # 第一次计算，直接使用当前角度
    #     prev_angle = angle_deg

    # # 确保角度在[-180, 180]范围内
    # angle_deg = (angle_deg + 180) % 360 - 180
    velocity_direction = angle_deg  # 单位: 度, 逆时针为正
    
    return velocity_direction


class KalmanVelocityDirection:
    """
    实时卡尔曼滤波速度方向估计器。
    
    状态向量： [x, y, vx, vy]^T
    流程：每次调用 update(x_meas, y_meas, freq)
      - freq==0 时输出 0 并冻结滤波器状态
      - freq>0 时：
          • 如果刚开始运动，重置滤波器状态为当前位置、零速度
          • 否则执行一次 KF predict + update
          • 输出 atan2(vy, vx)
    """
    def __init__(self,
                 dt: float,  
                 process_var: float = 0.01,
                 measure_var: float = 4.0,
                 init_P_var: float = 500.0):
        """
        参数:
          dt          : 采样周期 (s)
          process_var : 过程噪声方差标度 Q
          measure_var : 测量噪声方差标度 R
          init_P_var  : 初始协方差 P 的方差标度
        """
        self.dt = dt
        # 状态转移 & 测量矩阵
        self.F = np.array([[1, 0, dt, 0],
                           [0, 1, 0, dt],
                           [0, 0, 1,  0],
                           [0, 0, 0,  1]], dtype=float)
        self.H = np.array([[1, 0, 0, 0],
                           [0, 1, 0, 0]], dtype=float)
        self.Q = np.eye(4) * process_var
        self.R = np.eye(2) * measure_var
        
        # 初始状态
        self.init_P_var = init_P_var
        self.reset()

    def reset(self):
        """重置滤波器到未运动状态，下次有freq>0时会重新初始化。"""
        self.x_hat = np.zeros(4)           # [x, y, vx, vy]
        self.P     = np.eye(4) * self.init_P_var
        self._moving = False

    def update(self, x_meas: float, y_meas: float, freq: float) -> tuple:
        """
        传入当前帧测量 (x_meas, y_meas) 和旋转频率 freq。
        返回当前速度方向 (rad) 和滤波后的坐标 (x_filtered, y_filtered)。
        """
        # 频率为 0 → 静止
        if freq == 0:
            self._moving = False
            return 0.0, (x_meas, y_meas)
        
        # 由静止转为运动：重置状态
        if not self._moving:
            self.x_hat[:2] = [x_meas, y_meas]
            self.x_hat[2:] = [0.0, 0.0]
            self.P = np.eye(4) * self.init_P_var
            self._moving = True
        
        # ——— 预测
        self.x_hat = self.F @ self.x_hat
        self.P     = self.F @ self.P @ self.F.T + self.Q
        
        # ——— 更新
        z       = np.array([x_meas, y_meas])
        y_res   = z - (self.H @ self.x_hat)
        S       = self.H @ self.P @ self.H.T + self.R
        K       = self.P @ self.H.T @ np.linalg.inv(S)
        self.x_hat = self.x_hat + (K @ y_res)
        self.P     = (np.eye(4) - K @ self.H) @ self.P
        
        # 获取滤波后的坐标
        x_filtered, y_filtered = self.x_hat[0], self.x_hat[1]
        
        # 计算方向并返回
        vx, vy = self.x_hat[2], self.x_hat[3]
        vel_dir = np.arctan2(vy, vx)
        vel_dir = - np.rad2deg(vel_dir)
        
        return vel_dir, (x_filtered, y_filtered)


def signed_distance_to_path(robot_pos: np.ndarray, path: np.ndarray):
    """
    计算机器人坐标到轨迹的最短有向距离（向量化简洁版）。
    """
    if path is None or len(path) < 2:
        return 0.0, None, None, None

    P0, P1 = path[:-1, :2], path[1:, :2]
    v = P1 - P0
    w = robot_pos[:2] - P0
    denom = np.einsum('ij,ij->i', v, v)
    t = np.clip(np.einsum('ij,ij->i', w, v) / np.where(denom==0, 1, denom), 0, 1)
    proj = P0 + t[:, None] * v
    diff = robot_pos[:2] - proj
    dist = np.linalg.norm(diff, axis=1)
    dist[denom==0] = np.inf
    idx = np.argmin(dist)
    
    if not np.isfinite(dist[idx]):
        return 0.0, None, None, None
    tangent = v[idx]
    normal  = np.array([-tangent[1], tangent[0]])
    sign    = np.sign(np.dot(diff[idx], normal))
    # print(f'robot_pos: {robot_pos}, closest_path_point: {proj[idx]}, dist: {dist[idx]*sign}')
    return -(dist[idx] * sign), proj[idx], tangent, normal

def outer_controller_with_compensation_step(path, x: float, y: float, dzdx=None, dzdy=None, ks= 30, M: float=60):
    """带有坡度补偿的向量场生成，给路径和机器人位置坐标，返回alpha0和d"""
    eps = 1e-12
    gx = float(bilinear_interpolate(dzdx, x, y))
    gy = float(bilinear_interpolate(dzdy, x, y))
    g_norm = math.hypot(gx, gy)
    if g_norm < eps:
        s = np.array([0, -1])
    else:
        s = np.array([gx, gy])/g_norm
    pos = np.array((x,y))
    d, _, nq, nperp = signed_distance_to_path(pos, path)
    s_bar = np.dot(s,  np.sign(d)*nperp)
    if s_bar < 0:
        beta = -d
    else:
        beta = 0
    S = abs(d) + M + abs(ks*g_norm*s_bar * beta)
    w_d = d/S
    w_q = M/S
    w_s = ks*g_norm*s_bar * beta/S
    nStar = w_d * nperp + w_q * nq + w_s * s
    
    nStar = nStar / np.linalg.norm(nStar)
    thetaStar = math.atan2(nStar[1], nStar[0])
    alpha0    = -np.rad2deg(thetaStar) # 角度规范化，逆时针为正
    
    return alpha0, d

class PIDController:
    def __init__(self, dt: float, kp: float, ki: float, kd: float,
                 integrator_limit: float = None): # type: ignore
        """
        简化版 PID 控制器（单位采样 dt=1）

        参数:
            kp, ki, kd: PID 增益
            integrator_limit: 积分限幅，用于防止积分饱和
        """
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.dt = dt
        self.integrator = 0.0
        self.prev_error = 0.0
        self.integrator_limit = integrator_limit

    def reset(self):
        """重置积分和历史误差"""
        self.integrator = 0.0
        self.prev_error = 0.0

    def update(self, setpoint: float, measurement: float) -> float:
        """PID 控制器（固定时间步长 dt）

        参数:
            kp, ki, kd: PID 增益
            dt: 固定时间步长（秒）
            integrator_limit: 积分项限幅，防止积分饱和"""
        # 计算误差
        error = setpoint - measurement
        # ================= 这块为针对角度误差定制，确保误差在[-180,180]范围内 =================
        if error > 180:
            error -= 360
        elif error < -180:
            error += 360
        # ========================================================================
        P = self.kp * error
        self.integrator += error * self.dt
        if self.integrator_limit is not None:
            self.integrator = max(min(self.integrator, self.integrator_limit), -self.integrator_limit)
        I = self.ki * self.integrator
        derivative = (error - self.prev_error)/ self.dt
        D = self.kd * derivative
        self.prev_error = error

        output = P + I + D
        output = max(-30, min(output, 30))
        
        return output
    
    
class ESO:
    """
    三阶扩展状态观测器 (Extended State Observer)
    
    用于估计系统状态和外部扰动，并提供扰动补偿控制。
    基于线性扩展状态观测器原理，可以观测和补偿未知扰动。
    
    属性:
        b0 (float): 系统标称带宽
        omega_o (float): ESO 带宽
        L1 (float): ESO 增益1
        L2 (float): ESO 增益2
        L3 (float): ESO 增益3
        z1 (float): ESO 状态1，估计系统输出
        z2 (float): ESO 状态2，估计系统输出的导数
        z3 (float): ESO 状态3，估计系统扰动
        dt (float): 采样时间
    """
    
    def __init__(self, b0=1.0, omega_o=1.27, dt = 0.5):
        """
        初始化扩展状态观测器
        
        参数:
            b0 (float): 系统标称带宽
            omega_o (float): ESO 带宽，通常设置为 8*b0
            dt (float): 采样时间，默认为0.5秒
        """
        self.b0 = b0
        self.omega_o = omega_o
        self.dt = dt
        self.L1 = 3 * omega_o
        self.L2 = 3*omega_o**2
        self.L3 = omega_o**3
        self.z1 = 0.0  # ESO 状态1 y
        self.z2 = 0.0  # ESO 状态2 doty
        self.z3 = 0.0  # ESO 状态3 d
        self.count = 0
        
    def reset(self, measure):
        """
        重置观测器状态
        """
        measure = np.deg2rad(measure)
        self.z1 = measure
        self.z2 = 0.0
        self.z2 = 0.0
        
    def update(self, measure, u):
        """
        更新ESO状态
        
        参数:
            measure (float): 系统输出/测量值
            u (float, optional): 当前控制输入
            
        返回:
            tuple: (z1, z2, z3, control_output) 更新后的状态估计, 扰动估计。去除估计扰动后的控制输出
        """
        
        # ESO 状态更新（欧拉法）
        measure = np.deg2rad(measure)
        u = np.deg2rad(u)
        
        eo = measure - self.z1  # 输出误差
        self.z1 = self.z1 + self.dt * (self.z2 + self.b0 * (u - self.z1) + self.L1 * eo)
        self.z2 = self.z2 + self.dt * (self.z3 + self.L2 * eo)
        self.z3 = self.z3 + self.dt * (self.L3 * eo)
        
        y_hat = self.z1
        y_dot_hat = self.z2
        d_hat = self.z3
        compensation = - d_hat / self.b0
        control_output = u + compensation

        y_hat = np.rad2deg(y_hat)
        y_dot_hat = np.rad2deg(y_dot_hat)
        d_hat = np.rad2deg(d_hat)
        compensation = np.rad2deg(compensation)
        control_output = np.rad2deg(control_output)

        self.count += 1
        return y_hat, y_dot_hat, d_hat, compensation, control_output
    

