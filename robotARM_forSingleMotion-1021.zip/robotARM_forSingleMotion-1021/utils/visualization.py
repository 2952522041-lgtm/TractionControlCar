
import numpy as np
import math
import matplotlib.pyplot as plt
from tqdm import tqdm
from path import *
import time
from scipy import ndimage as ndi
from matplotlib.colors import LinearSegmentedColormap
from path import plot_straight_line, plot_one_period_sine
def calc_grad(Z: np.ndarray, cellsize: float = 1.0):
    """
    5×5 局部平面最小二乘近似 DEM 梯度。
    返回 dzdx, dzdy，与 Z 同形状。
    """
    coords = np.arange(-2, 3)
    qx = coords / (50 * cellsize)
    kernel_x = np.tile(qx, (5, 1))
    kernel_y = kernel_x.T
    dzdx = ndi.convolve(Z, kernel_x, mode="nearest")
    dzdy = ndi.convolve(Z, kernel_y, mode="nearest")
    return dzdx, dzdy

def signed_distance_to_path(robot_pos: np.ndarray, path: np.ndarray):
    """
    计算机器人坐标到轨迹的最短有向距离（向量化简洁版）。
    """
    if path is None or len(path) < 2:
        return 0.0, None, None, None

    P0, P1 = path[:-1, :2], path[1:, :2]
    v = P1 - P0
    w = robot_pos[:2] - P0
    denom = np.einsum('ij,ij->i', v, v)
    t = np.clip(np.einsum('ij,ij->i', w, v) / np.where(denom==0, 1, denom), 0, 1)
    proj = P0 + t[:, None] * v
    diff = robot_pos[:2] - proj
    dist = np.linalg.norm(diff, axis=1)
    dist[denom==0] = np.inf
    idx = np.argmin(dist)

    if not np.isfinite(dist[idx]):
        return 0.0, None, None, None

    tangent = v[idx]
    normal  = np.array([-tangent[1], tangent[0]])
    sign    = np.sign(np.dot(diff[idx], normal))
    return -(dist[idx] * sign), proj[idx], tangent, normal

def outer_controller_with_compensation_step(path, x: float, y: float, dzdx, dzdy, ks= 30, M: float=60):
    """带有坡度补偿的向量场生成"""
    eps = 1e-12
    gx = float(dzdx[y, x])
    gy = float(dzdy[y, x])
    g_norm = math.hypot(gx, gy)
    if g_norm < eps:
        s = np.array([0, -1])
    else:
        s = np.array([gx, gy])/g_norm
    pos = np.array((x,y))
    d, _, nq, nperp = signed_distance_to_path(pos, path)
    
    s_bar = np.dot(s,  np.sign(d)*nperp)
    if s_bar < 0:
        beta = -d
    else:
        beta = 0
    S = abs(d) + M + abs(ks*g_norm*s_bar * beta)

    w_d = d/S
    w_q = M/S
    w_s = ks*g_norm*s_bar * beta/S
    nStar = w_d * nperp + w_q * nq + w_s * s

    nStar = nStar / np.linalg.norm(nStar)

    return nStar

def visualize_nStar_field():
    
    x1,x2 = 0,2048
    y1,y2 = 0,2048
    mm_per_pixel = 0.15054751   # 每个像素对应的毫米数
    
    # Z = np.ones((2048, 2048), dtype=float)
    Z = np.load('utils/terrain_dem_10deg_slope_2048by2048.npy')
    # print("DEM shape:", Z.shape)
    # path = plot_straight_line()
    path = plot_straight_line()
    path_xy = path[:, :2]

    dzdx, dzdy = calc_grad(Z, cellsize=1.0)
    
    plt.figure(figsize=(10, 10))
    custom_cmap = LinearSegmentedColormap.from_list("my_cmap", ["#132582",
    "#214ca8", "#3179c1", "#67d3da", "#92d077", "#f5e445", "#ff7d24", "#ff2f17","#931d17"])
    
    elev_map = plt.imshow(Z, extent=(x1, x2, y2, y1), origin='upper', cmap=custom_cmap, alpha=1)
    cbar = plt.colorbar(
        elev_map,
        label='Elevation',
        fraction=0.046,   # 长度约为主图的 4.6%
        pad=0.04          # 与主图右侧留 4% 宽度 空白
    )
    plt.xlim(x1, x2)
    plt.ylim(y2, y1)  # 反转y轴，使向下为y正方向
    plt.title('nStar Vector Field Visualization')
    plt.xlabel('X (pixel)')
    plt.ylabel('Y (pixel)')
    plt.plot(path_xy[:, 0], path_xy[:, 1], 'r', lw = '2',label='Reference Path')

    # 设置采样点密度
    step = 64  # 每隔32像素采样一个点

    # 遍历画布上的点
    for x in tqdm(range(x1, x2, step), desc='Processing columns'):
        for y in range(y1, y2, step):
            nStar = outer_controller_with_compensation_step(path, x, y,dzdx,dzdy)
            scale = 20  # 缩放因子
            dx = nStar[0] * scale
            dy = nStar[1] * scale
            plt.arrow(x, y, dx, dy,
                      head_width=20, head_length=20,
                      fc='w', ec='w', alpha=0.8)
    # 添加图例
    plt.legend()
    plt.show()


if __name__ == "__main__":
    visualize_nStar_field()