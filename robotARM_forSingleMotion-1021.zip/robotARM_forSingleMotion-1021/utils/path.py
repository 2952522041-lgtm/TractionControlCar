import numpy as np
import matplotlib.pyplot as plt

# def plot_one_period_sine(A = 40, w = 0.01, phi=950, B=800, N=50):
def plot_one_period_sine(A = -120, w = 0.005, phi=220, B=1200, N=50, rotation_angle=0):

    """
    在2048×2048画布上绘制一个完整周期的正弦波，并返回N个点的坐标。

    参数:
        A: 振幅（像素）
        w: 角频率（弧度/像素）
        phi: x坐标右移程度（像素）
        B: 垂直偏移（像素）
        N: 采样点数
        rotation_angle: 旋转角度（度），正值为顺时针旋转

    返回:
        points: 包含N个点(x,y)的列表，x范围覆盖一个周期，y在[0, 2048]内
    """
    # A = 50, w = 0.01, phi=962, B=650, N=20
    # 计算一个完整周期的长度（像素）
    period_length = 2 * np.pi / w  # T = 2π/w

    # 生成x坐标（覆盖一个周期）
    x = np.linspace(phi, phi+period_length, N)
    
    # 计算y坐标   起点坐标（phi，B）
    y = A * np.sin(w * (x-phi)) + B

    # 如果需要旋转，应用旋转变换
    if rotation_angle != 0:
        # 将角度转换为弧度
        angle_rad = np.radians(rotation_angle)
        
        # 旋转中心设为画布中心 (1024, 1024)
        center_x, center_y = 1024, 1024
        
        # 将坐标平移到以原点为中心
        x_centered = x - center_x
        y_centered = y - center_y
        
        # 应用旋转矩阵（顺时针旋转）
        cos_angle = np.cos(angle_rad)
        sin_angle = np.sin(angle_rad)
        
        x_rotated = x_centered * cos_angle + y_centered * sin_angle
        y_rotated = -x_centered * sin_angle + y_centered * cos_angle
        
        # 将坐标平移回原来的位置
        x = x_rotated + center_x
        y = y_rotated + center_y

    points = np.column_stack((np.round(x).astype(int), np.round(y).astype(int)))
    return points

def plot_straight_line(y=900, N=50):
    """
    在2048×2048画布上绘制一条直线，并返回N个点的坐标。

    参数:
        y: 直线的y坐标（像素）
        N: 采样点数

    返回:  points: 包含N个点(x,y)的列表，x范围覆盖一个周期，y在[0, 2048]内
    """
    # 生成x坐标（覆盖一个周期）
    x = np.linspace(500, 1300, N)
    # y = 2*x+1*np.ones(N)
    y = y*np.ones(N)
    points = np.column_stack((np.round(x).astype(int), np.round(y).astype(int)))
    return points

def plot_inclined_line(N=500):
    """
    在2048×2048画布上绘制一条直线，并返回N个点的坐标。

    参数:
        y: 直线的y坐标（像素）
        N: 采样点数

    返回:  points: 包含N个点(x,y)的列表，x范围覆盖一个周期，y在[0, 2048]内
    """
    # 生成x坐标（覆盖一个周期）
    x = np.linspace(250, 750, N)
    # y = 2*x+1*np.ones(N)
    y = x
    points = np.column_stack((np.round(x).astype(int), np.round(y).astype(int)))
    return points

def plot_circle(cx=1200, cy=1000, r=350, N=120):
    """
    在2048×2048画布上绘制一个圆，并返回N个点的坐标。

    参数:
        r: 圆的半径（像素）
        N: 采样点数

    返回:
        points: 包含N个点(x,y)的列表，x范围覆盖一个周期，y在[0, 2048]内
    """
    # 生成x坐标（覆盖一个周期）
    t = np.linspace(-np.pi, np.pi, N, endpoint=True)
    x = cx + r * np.cos(t)
    y = cy + r * np.sin(t)
    points = np.column_stack((np.round(x).astype(int), np.round(y).astype(int)))
    return points

def plot_quard(A=0.001, B=800,C=1000,N=500):
    """绘制二次曲线"""


    x = np.linspace(300, 1610, N)
    y = A*(x-B)**2+C
    points = np.column_stack((np.round(x).astype(int), np.round(y).astype(int)))

    return points

def plot_infinity(cx=1024, cy=800, a=400, N=160):
    """
    在 2048×2048 画布上绘制一个无穷大(∞)形状，并返回 N 个点的整数像素坐标。

    参数:
        cx, cy   : 图形中心（像素）
        a        : 形状尺度（像素）。近似理解为单侧“环”的半宽量级
        N        : 采样点数（越大越平滑）
        angle_deg: 整体旋转角（度），0 表示水平放置的“∞”

    返回:
        points(np.ndarray): 形如 (N,2) 的整数数组，每行是 (x, y)
    """
    # 伯努利双纽线的一个常用参数方程:
    # x(t) = (a * cos t) / (1 + sin^2 t)
    # y(t) = (a * sin t * cos t) / (1 + sin^2 t)
    t = np.linspace(np.pi, -np.pi, N, endpoint=True)
    s2 = np.sin(t)**2
    denom = 1.0 + s2

    x = cx + (a * np.cos(t)) / denom
    y = cy + (a * np.sin(t) * np.cos(t)) / denom

    # 转为像素坐标
    points = np.column_stack((np.round(x).astype(int), np.round(y).astype(int)))

    return points