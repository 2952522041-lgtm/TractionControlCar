"""
多足机器人控制系统主程序
"""
import cv2, time, threading, sys
from utils.coordinate_converter import CoordinateConverter
from vision.camera_manager import CameraManager
from config.settings import ROBOT_CONFIG, SERIAL_CONFIG
from utils.logger import setup_logger
from robot.dobot_arm import DobotArm
from robot.motor import Motor
from PyQt5.QtWidgets import QApplication
from utils.data_recorder import DataRecorder
from robot.ui import RobotControlUI
from utils.Controller import ESO, outer_controller_with_compensation_step, KalmanVelocityDirection, calc_grad, signed_distance_to_path
from utils.fuzzy_pid_controller import FuzzyLogicController, FuzzyAdaptivePID
import numpy as np
import matplotlib
from utils.path import plot_one_period_sine, plot_straight_line
matplotlib.use('Qt5Agg')


# ============================= 设置日志与全局变量 =============================
logger = setup_logger("RobotControl", "robot_control.log")
current_coord = None
coord_lock = threading.Lock()
coord_history = []  # 存储最近轨迹点
max_history_len = 40  # 最多保存20个点
running = True
paused = False
actuation_running = False
rz_frozen = False
pose_cmd = None
dt = 0.1
sequence_running = False
sequence_step = 0
sequence_start_time = 0
status_info = {
    'camera': '未连接',
    'dobot': '未连接',
    'motor': '未连接',
    'system': '未启动',
    'actuation': '未启动',
    'rz_frozen': '未冻结',
    'target': '无',
    'pose': '无',
    'command': '无',
    'recording': '未开始',
    'alpha_cmd': '无',
    'orientation': '无',
    'alpha0_deg': '无',
    'delta_alpha_deg': '无',
    'psi_v': '无',
    'psi_v_hat_deg': '无',
    'eso_comp_deg': '无',
    'alpha_cmd_eso_deg': '无',
    'distur_hat': '无',
    'signed_dist': '无',
    'filtered_coords': '无',
    'sequence': False,
    'sequence_step': 0,
}

# =============================== 初始化组件 ===============================
cc = CoordinateConverter()
dobot = DobotArm(ROBOT_CONFIG['ip'], ROBOT_CONFIG['ports'], logger)
motor = Motor(SERIAL_CONFIG['port'], SERIAL_CONFIG['baud_rate'], logger=logger)
data_recorder = DataRecorder()
data_recorder.initialize(logger=logger)
is_recording = False

# ============================= 初始化控制器 =============================
fuzzy_logic_controller = FuzzyLogicController()
fuzzy_pid = FuzzyAdaptivePID(kp_base=0.1, ki_base=0.05, kd_base=0.001,fuzzy_logic_controller = fuzzy_logic_controller, integrator_limit=15, dt=dt)

eso = ESO(b0=0.5, omega_o=0.84, dt=dt)
velocity_direction_calculator = KalmanVelocityDirection(dt=dt, process_var=0.01, measure_var=4.0, init_P_var=500.0)

# ============================= 加载路径与地形数据 =============================  
# Z = np.load('utils/terrain_dem_10deg_slope_2048by2048.npy').astype(float)
Z = np.ones((2048,2048), dtype=float)
# path = np.load('utils/smoothed_path_rand.npy',allow_pickle=True)
# path = plot_straight_line()
path = plot_one_period_sine()
dzdx, dzdy = calc_grad(Z, cellsize=1.0)

def camera_thread():
    global camera, current_coord, running, paused, status_info, ui
    try:
        camera = CameraManager(logger)
        if not camera.setup():
            logger.error("相机初始化失败，退出相机线程")
            status_info['camera'] = '初始化失败'
            running = False
            return
        status_info['camera'] = '已连接'
        camera.begin_acquisition()
        
        while running:
            if paused:
                time.sleep(0.1)
                continue
            ok, image_data, image_result = camera.get_next_image()
            if (not ok) or (image_result is None):
                time.sleep(0.1)
                continue
            if 'ui' in globals() and ui is not None:
                ui.raw_image_signal.emit(image_data)
            drawn_image, rect_info = camera.process_image(image_data, area_threshold=100, binary_threshold=160)
            if is_recording:
                trajectory_points = data_recorder.get_trajectory_points()
                if trajectory_points and len(trajectory_points) > 1:
                    points = np.array(trajectory_points, dtype=np.int32)
                    cv2.polylines(drawn_image, [points], False, (0, 255, 0), 5)
                    
            if hasattr(data_recorder, 'is_recording_video') and data_recorder.is_recording_video:
                data_recorder.write_video_frame(drawn_image)
            if 'ui' in globals() and ui is not None:
                ui.processed_image_signal.emit(drawn_image)
            with coord_lock:
                if rect_info and 'center' in rect_info:
                    center = rect_info['center']
                    angle = rect_info.get('angle', 0.0)
                    current_coord = (center[0], center[1], angle)
                    status_info['target'] = f"({center[0]:.2f}, {center[1]:.2f})"
                    status_info['orientation'] = f"{angle:.2f}°"
                else:
                    current_coord = None
                    status_info['target'] = '无'
                    status_info['orientation'] = '无'
            image_result.Release()
            time.sleep(0.01)
    except Exception as e:
        logger.error(f"相机线程异常: {e}")
        status_info['camera'] = '异常'
    finally:
        logger.info("相机线程退出")
        status_info['camera'] = '已断开'

def init_devices():
    global running
    try:
        # 初始化机械臂与电机
        if not (dobot.connect() and dobot.initialize()):
            running = False
            return False
        status_info['dobot'] = '已连接'

        if not (motor.connect() and motor.initialize()):
            running = False
            return False
        status_info['motor'] = '已连接'
        logger.info("运动线程启动")
        status_info['system'] = '运行中'
        return True
    except Exception as e:
        logger.error(f"运动线程异常: {e}")
        status_info['system'] = '异常'
    finally:
        dobot.stop_motion()  # 停止机械臂运动
        logger.info("运动线程退出")
        status_info['system'] = '已停止'
    
def xy_compensation(rz_deg):
    t = np.deg2rad(rz_deg)
    dx = 10.0136*np.cos(t) + 1.1246*np.sin(t) + 0.4630
    dy = -2.1681*np.cos(t) + 9.3872*np.sin(t) + 9.5925
    return dx, dy

def motion_thread():
    global current_coord, running, status_info, calc_flange_pose, control_input, rz_frozen, pose_cmd
    calc_flange_pose = [0, 0, 400, 0, 0, -90]
    frozen_rz = -90
    if not init_devices():
        return
    while running:
        if paused:
            status_info['system'] = '已暂停'
            time.sleep(0.1)
            continue
        else:
            status_info['system'] = '运行中'
        
        # ================================ 传感器数据采集 与 状态估计 ================================
        pose = dobot.get_flange_pose()
        if pose: status_info['pose'] = f"X={pose[0]:.2f}, Y={pose[1]:.2f}, Z={pose[2]:.2f}, RX={pose[3]:.2f}, RY={pose[4]:.2f}, RZ={pose[5]:.2f}"
        with coord_lock:
            curr = current_coord if current_coord else None
        try:
            motor_speed = motor.get_current_speed()
            if not curr:
                time.sleep(0.1)
                continue
            u, v, orientation = curr  # 解包坐标元组 (x, y, angle)
            calc_flange_pose = cc.image_to_calc_flange_pose(u, v, 400)
            pose_x, pose_y, pose_z, pose_rx, pose_ry, pose_rz = calc_flange_pose
            # 速度估计
            psi_v, (filtered_x, filtered_y) = velocity_direction_calculator.update(u, v, motor_speed)
            
            # ================================ 控制器 ================================
            if not actuation_running:
                alpha0_deg = 0 # desired 方向
                delta_alpha_deg = 0 # pid 输出
                alpha_cmd_deg = 0 # 最终控制量（alpha0+delta_alpha）
                psi_v_hat = 0 # 速度方向估计
                distur_hat = 0 # 扰动估计
                eso_comp_deg = 0 # eso给的扰动补偿增量
                alpha_cmd_eso_deg = 0 # 最终控制量（alpha0 + pid + eso补偿）
                signed_dist = 0 # 有向横向距离
            else:
                alpha0_deg, _ = outer_controller_with_compensation_step(path, filtered_x, filtered_y, dzdx, dzdy, ks=0, M=80)
                signed_dist, _, _, _ = signed_distance_to_path((u,v), path)
                delta_alpha_deg = fuzzy_pid.compute(alpha0_deg, psi_v)
                alpha_cmd_deg = alpha0_deg + delta_alpha_deg
                if eso.count == 0:
                    eso.reset(psi_v)
                psi_v_hat, _, distur_hat, eso_comp_deg, alpha_cmd_eso_deg = eso.update(psi_v, alpha_cmd_deg)
                
            # 选定控制信号到哪一级
            # control_cmd = alpha_cmd_eso_deg
            control_cmd = alpha0_deg
            
            # ------------------ 控制信号变化量限幅 ------------------
            if not hasattr(motion_thread, 'last_alpha_cmd_deg'):
                motion_thread.last_alpha_cmd_deg = control_cmd
            else:
                delta = control_cmd - motion_thread.last_alpha_cmd_deg
                if abs(delta) > 10:
                    control_cmd = motion_thread.last_alpha_cmd_deg + 10 * np.sign(delta)
                motion_thread.last_alpha_cmd_deg = control_cmd
            
            control_input = control_cmd
            # =============================== 生成机械臂运动指令 ===============================
            if actuation_running:
                if rz_frozen:  # 现在使用全局的rz_frozen
                    # rz被冻结时，使用冻结的值
                    rz = frozen_rz
                else:
                    # rz未冻结时，rz跟随control_input
                    rz = control_input - 90
                    if -270 < rz < -180:
                        rz += 360
                    # ------- 限幅rz -------
                    rz = np.clip(rz, -150, -30)
                    # rz = -135
                    # ------- 对rz进行补偿 ------
                    dx, dy = xy_compensation(rz)
                    pose_x = pose_x + dx
                    pose_y = pose_y + dy
                    print(f"补偿dx={dx:.2f}, dy={dy:.2f}")
                    # ------ 限幅rz结束-------
                    frozen_rz = rz  # 更新冻结值为当前值
                # 设置默认Z坐标
                current_z = 434
            else:
                # actuation未启动时，rz固定为-90度
                rz = -90
                frozen_rz = rz
                current_z = 434

            # 130
            pose_cmd = (pose_x, pose_y, 434, 0, 0, rz)
            # pose_cmd = (250,250,434,0,0,-45)

            # ================================= 更新状态信息与记录数据 ================================
            status_info['psi_v'] = f"{psi_v:.2f}°"
            status_info['filtered_coords'] = f"({filtered_x:.2f}, {filtered_y:.2f})"
            status_info['psi_v_hat'] = f"{psi_v_hat:.2f}"
            status_info['distur_hat'] = f"{distur_hat:.2f}"
            status_info['eso_comp_deg'] = f"{eso_comp_deg:.2f}"
            status_info['signed_dist'] = f"{signed_dist:.2f}"
            status_info['alpha_cmd'] = f"{alpha_cmd_deg:.2f}°"
            status_info['alpha0_deg'] = f"{alpha0_deg:.2f}"
            status_info['delta_alpha_deg'] = f"{delta_alpha_deg:.2f}"
            status_info['alpha_cmd_eso_deg'] = f"{alpha_cmd_eso_deg:.2f}"
            status_info['rz_frozen'] = '已冻结' if rz_frozen else '未冻结'
            
            if is_recording:
                motor_speed = motor.get_current_speed() if hasattr(motor, 'get_current_speed') else 0.0
                pid_error = alpha0_deg - psi_v
                
                data_recorder.add_record(
                    motor_speed, u, v, orientation, alpha0_deg, delta_alpha_deg,
                    psi_v, pid_error, alpha_cmd_deg, psi_v_hat, distur_hat,
                    eso_comp_deg, alpha_cmd_eso_deg, signed_dist, filtered_x, filtered_y
                )

            time.sleep(0.1) # 控制频率10Hz

        except Exception as e:
            logger.error(f"运动控制出错: {e}")

def actuation_thread():
    global pose_cmd
    while running:
        if not actuation_running or not pose_cmd:
            time.sleep(0.1)
            continue
        dobot.send_movL_command(pose_cmd)
        status_info['command'] = f"X={pose_cmd[0]:.2f}, Y={pose_cmd[1]:.2f}, Z={pose_cmd[2]:.2f}, RX={pose_cmd[3]:.2f}, RY={pose_cmd[4]:.2f}, RZ={pose_cmd[5]:.2f}"
        time.sleep(0.5) # 执行器频率2Hz

def sequence_thread():
    """控制序列线程"""
    global sequence_running, sequence_step, sequence_start_time, rz_frozen, status_info, running, pose_cmd, rz, frozen_rz
    
    while running:
        if not sequence_running:
            # 重置序列状态
            if sequence_step != 1:
                sequence_step = 1
                sequence_start_time = 0
                status_info['sequence'] = False
                status_info['sequence_step'] = 0
                rz_frozen = False
            time.sleep(0.1)
            continue
            
        current_time = time.time()
        
        if sequence_step == 1:
            # 步骤1：开启后首先rz跟着control_input调节，持续3s
            if sequence_start_time == 0:
                sequence_start_time = current_time
                rz_frozen = False
                status_info['sequence'] = True
                status_info['sequence_step'] = 1
                logger.info("控制序列步骤1开始：RZ跟随控制量")
            if current_time - sequence_start_time >= 3:
                sequence_step = 2
                sequence_start_time = current_time
                
        elif sequence_step == 2:
            # 步骤2：冻结rz，等待1s
            if current_time - sequence_start_time < 0.1:
                rz_frozen = True
                status_info['sequence_step'] = 2
                logger.info("控制序列步骤2开始：冻结RZ")
            if current_time - sequence_start_time >= 1:
                sequence_step = 3
                sequence_start_time = current_time
                
        elif sequence_step == 3:
            # 步骤3：电机步进45度，等待3s
            if current_time - sequence_start_time < 0.1:
                logger.info("控制序列步骤3开始：电机步进45度")
                motor.step(speed=0.3, direction=0, angle=45)
                status_info['sequence_step'] = 3
            if current_time - sequence_start_time >= 3:
                sequence_step = 4
                sequence_start_time = current_time
                
        elif sequence_step == 4:
            # 步骤4：开启后首先rz跟着control_input调节，持续3s
            if current_time - sequence_start_time < 0.1:
                rz_frozen = False
                logger.info("控制序列步骤4开始：RZ跟随控制量")
                status_info['sequence_step'] = 4
            if current_time - sequence_start_time >= 3:
                sequence_step = 5
                sequence_start_time = current_time
                
        elif sequence_step == 5:
            # 步骤5：冻结rz，等待2s
            if current_time - sequence_start_time < 0.1:
                rz_frozen = True
                status_info['sequence_step'] = 5
                logger.info("控制序列步骤5开始：冻结RZ")
            if current_time - sequence_start_time >= 1:
                sequence_step = 6
                sequence_start_time = current_time
        
        elif sequence_step == 6:
            # 步骤8：电机步进90度，等待5s
            if current_time - sequence_start_time < 0.1:
                motor.step(speed=0.3, direction=0, angle=90)
                status_info['sequence_step'] = 6
                logger.info("控制序列步骤6开始：电机步进90度")
            if current_time - sequence_start_time >= 2:
                sequence_step = 7
                sequence_start_time = current_time
                
        if sequence_step == 7:
            # 步骤7：开启后首先rz跟着control_input调节，持续3s
            if sequence_start_time == 0:
                sequence_start_time = current_time
                rz_frozen = False
                status_info['sequence'] = True
                status_info['sequence_step'] = 7
                logger.info("控制序列步骤7开始：RZ跟随控制量")
            if current_time - sequence_start_time >= 3:
                sequence_step = 8
                sequence_start_time = current_time
                
        elif sequence_step == 8:
            # 步骤8：冻结rz，等待2s
            if current_time - sequence_start_time < 0.1:
                rz_frozen = True
                status_info['sequence_step'] = 8
                logger.info("控制序列步骤8开始：冻结RZ")
            
            if current_time - sequence_start_time >= 1:
                sequence_step = 9
                sequence_start_time = current_time
                
        elif sequence_step == 9:
            # 步骤9：电机步进45度，等待3s
            if current_time - sequence_start_time < 0.1:
                logger.info("控制序列步骤9开始：电机步进45度")
                motor.step(speed=0.3, direction=0, angle=45)
                status_info['sequence_step'] = 9
                rz = pose_cmd[5] # type: ignore
            if current_time - sequence_start_time >= 3:
                sequence_step = 1
                sequence_start_time = current_time
                
        time.sleep(0.05)


def main():
    global running, paused, ui
    threads = []
    app = QApplication(sys.argv)
    try:
        class GlobalVars:
            @property
            def running(self):
                global running
                return running
                
            @running.setter
            def running(self, value):
                global running
                running = value
                
            @property
            def paused(self):
                global paused
                return paused
                
            @paused.setter
            def paused(self, value):
                global paused
                paused = value
            
            @property
            def is_recording(self):
                global is_recording
                return is_recording
                
            @is_recording.setter
            def is_recording(self, value):
                global is_recording
                is_recording = value
                status_info['recording'] = '记录中' if value and not self.paused else '未开始'
                    
            @property
            def actuation_running(self):
                global actuation_running
                return actuation_running
                
            @actuation_running.setter
            def actuation_running(self, value):
                global actuation_running
                actuation_running = value
                
            @property
            def sequence_running(self):
                global sequence_running
                return sequence_running
                
            @sequence_running.setter
            def sequence_running(self, value):
                global sequence_running
                sequence_running = value
        
        global_vars = GlobalVars()
        
        global ui
        ui = RobotControlUI(status_info, logger, global_vars, 
                           camera_thread, motion_thread, motor, data_recorder)
        ui.show()
        
        # 启动线程
        cam_thread = threading.Thread(target=camera_thread, daemon=True, name='CameraThread')
        cam_thread.start()
        threads.append(cam_thread)
        logger.info("相机线程已启动")
        
        mot_thread = threading.Thread(target=motion_thread, daemon=True, name='MotionThread')
        mot_thread.start()
        threads.append(mot_thread)
        logger.info("运动线程已启动")
        
        act_thread = threading.Thread(target=actuation_thread, daemon=True, name='ActuationThread')
        act_thread.start()
        threads.append(act_thread)
        logger.info("执行线程已启动")
        
        seq_thread = threading.Thread(target=sequence_thread, daemon=True, name='SequenceThread')
        seq_thread.start()
        threads.append(seq_thread)
        logger.info("控制序列线程已启动")
        
        sys.exit(app.exec_())
            
    except Exception as e:
        logger.error(f"运行过程中发生异常: {e}")
    finally:
        running = False
        try:
            for thread in threads:
                thread.join(timeout=2)
                if thread.is_alive():
                    logger.warning(f"线程 {thread.name} 未能正常退出")
            if 'data_recorder' in globals() and data_recorder:
                if hasattr(data_recorder, 'is_recording_video') and data_recorder.is_recording_video:
                    data_recorder.stop_video_recording()
            motor.cleanup()
            dobot.close()
            camera.release()
        except Exception as e:
            logger.error(f"清理资源时出错: {e}")

if __name__ == "__main__":
    main()

