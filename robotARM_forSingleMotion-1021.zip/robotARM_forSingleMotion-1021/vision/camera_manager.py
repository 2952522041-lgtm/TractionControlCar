import PySpin
import cv2
import numpy as np
import logging
import json
import os
from utils.path import plot_straight_line, plot_one_period_sine, plot_circle, plot_infinity
from config.settings import CAMERA_CONFIG, ROI_CONFIG
from typing import cast, Any
class CameraManager:
    """
    相机管理类，封装了相机的初始化、配置、图像处理和资源释放等功能
    """
    def __init__(self, logger=None, enable_undistort=True):
        self.camera = None
        self.camera_list = None
        self.system = None
        self.is_initialized = False
        self.is_acquiring = False
        self.logger = logger or logging.getLogger("CameraManager")
        self.last_ang = None
        
        # 相机标定参数
        self.camera_matrix = None
        self.distortion_coefficients = None
        self.calibration_loaded = False
        self.enable_undistort = enable_undistort
        
        # 预计算的映射表（用于快速畸变校正）
        self.map1 = None
        self.map2 = None
        self.image_size = None
        
        # 加载相机标定参数
        self._load_calibration_data()

    
    def init_camera(self, camera_index=0):
        """
        初始化相机
        
        参数:
            camera_index: 相机索引，默认为0
            
        返回:
            bool: 初始化是否成功
        """
        try:
            self.system = cast(Any, PySpin.System).GetInstance()
            self.camera_list = self.system.GetCameras()
            if self.camera_list.GetSize() == 0:
                self.logger.error("No camera detected!")
                return False
            self.camera = self.camera_list.GetByIndex(camera_index)
            self.camera.Init()
            self.is_initialized = True
            self.logger.info("相机初始化成功")
            return True
        except PySpin.SpinnakerException as ex:
            self.logger.error(f"初始化相机时出错: {ex}")
            return False
    
    def _load_calibration_data(self):
        """
        加载相机标定数据
        
        从vision文件夹中的camera_calibration.json文件加载相机矩阵和畸变系数
        """
        try:
            # 获取当前文件所在目录
            current_dir = os.path.dirname(os.path.abspath(__file__))
            calibration_file = os.path.join(current_dir, 'camera_calibration.json')
            
            if os.path.exists(calibration_file):
                with open(calibration_file, 'r') as f:
                    calibration_data = json.load(f)
                
                # 转换为numpy数组
                self.camera_matrix = np.array(calibration_data['camera_matrix'], dtype=np.float32)
                self.distortion_coefficients = np.array(calibration_data['distortion_coefficients'], dtype=np.float32)
                
                self.calibration_loaded = True
                self.logger.info("相机标定参数加载成功")
            else:
                self.logger.warning(f"未找到相机标定文件: {calibration_file}")
                
        except Exception as e:
            self.logger.error(f"加载相机标定参数时出错: {e}")
    
    def _prepare_undistort_maps(self, image_shape):
        """
        预计算畸变校正映射表
        
        参数:
            image_shape: 图像形状 (height, width)
        """
        if not self.calibration_loaded:
            return
            
        try:
            h, w = image_shape[:2]
            self.image_size = (w, h)
            
            # 预计算映射表
            self.map1, self.map2 = cv2.initUndistortRectifyMap(
                self.camera_matrix, 
                self.distortion_coefficients, 
                None,  # 不进行立体校正
                self.camera_matrix,  # 使用原始相机矩阵
                self.image_size, 
                cv2.CV_16SC2  # 使用16位整数格式以节省内存
            )
            
            self.logger.info(f"畸变校正映射表预计算完成，图像尺寸: {self.image_size}")
            
        except Exception as e:
            self.logger.error(f"预计算映射表时出错: {e}")
            self.map1 = None
            self.map2 = None
    
    def undistort_image(self, image):
        """
        对图像进行畸变矫正（快速版本，使用预计算映射表）
        
        参数:
            image (ndarray): 输入的原始图像
            
        返回:
            ndarray: 矫正后的图像，如果标定参数未加载则返回原图像
        """
        if not self.calibration_loaded:
            self.logger.warning("相机标定参数未加载，跳过畸变矫正")
            return image
            
        try:
            # 检查是否需要重新计算映射表
            current_shape = image.shape
            if self.map1 is None or self.map2 is None or self.image_size != (current_shape[1], current_shape[0]):
                self._prepare_undistort_maps(current_shape)
            
            # 如果映射表准备失败，使用传统方法
            if self.map1 is None or self.map2 is None:
                return self._undistort_image_traditional(image)
            
            # 使用预计算的映射表进行快速校正
            undistorted_image = cv2.remap(image, self.map1, self.map2, cv2.INTER_LINEAR)
            return undistorted_image
            
        except Exception as e:
            self.logger.error(f"图像畸变矫正时出错: {e}")
            return image
    
    def _undistort_image_traditional(self, image):
        """
        传统的畸变矫正方法（备用）
        
        参数:
            image (ndarray): 输入的原始图像
            
        返回:
            ndarray: 矫正后的图像
        """
        try:
            # 使用cv2.undistort进行畸变矫正
            undistorted_image = cv2.undistort(image, self.camera_matrix, self.distortion_coefficients)
            return undistorted_image
        except Exception as e:
            self.logger.error(f"传统畸变矫正时出错: {e}")
            return image
    

    
    def benchmark_undistort_performance(self, test_image=None, iterations=100):
        """
        测试畸变校正性能
        
        参数:
            test_image (ndarray): 测试图像，如果为None则创建一个测试图像
            iterations (int): 测试迭代次数
            
        返回:
            dict: 包含性能测试结果的字典
        """
        if not self.calibration_loaded:
            self.logger.warning("相机标定参数未加载，无法进行性能测试")
            return None
            
        import time
        
        # 创建测试图像（如果未提供）
        if test_image is None:
            test_image = np.random.randint(0, 255, (2048, 2048), dtype=np.uint8)
            
        results = {}
        
        # 测试快速方法（预计算映射表）
        start_time = time.time()
        for _ in range(iterations):
            _ = self.undistort_image(test_image)
        fast_time = (time.time() - start_time) / iterations
        
        # 测试传统方法
        start_time = time.time()
        for _ in range(iterations):
            _ = self._undistort_image_traditional(test_image)
        traditional_time = (time.time() - start_time) / iterations
        
        results = {
            'fast_method_ms': fast_time * 1000,
            'traditional_method_ms': traditional_time * 1000,
            'speedup_ratio': traditional_time / fast_time if fast_time > 0 else 0,
            'image_size': test_image.shape,
            'iterations': iterations
        }
        
        self.logger.info(f"性能测试结果:")
        self.logger.info(f"  快速方法: {results['fast_method_ms']:.2f} ms/帧")
        self.logger.info(f"  传统方法: {results['traditional_method_ms']:.2f} ms/帧")
        self.logger.info(f"  性能提升: {results['speedup_ratio']:.2f}x")
        
        return results
    
    def set_undistort_enabled(self, enabled):
        """
        设置是否启用畸变校正
        
        参数:
            enabled (bool): 是否启用畸变校正
        """
        self.enable_undistort = enabled
        self.logger.info(f"畸变校正已{'启用' if enabled else '禁用'}")
        # 注意：映射表会在首次使用undistort_image时自动计算，无需在此处重复计算
    
    def configure_camera(self, exposure_time_value, gain_value, frame_rate_value):
        """
        配置相机参数
        
        参数:
            exposure_time_value: 曝光时间（微秒）
            gain_value: 增益值（dB）
            frame_rate_value: 帧率（FPS）
            
        返回:
            bool: 配置是否成功
        """
        if not self.is_initialized or self.camera is None:
            self.logger.error("相机未初始化，无法配置")
            return False
            
        try:
            # 设置图像格式为 Mono8
            nodemap = self.camera.GetNodeMap()
            pixel_format = PySpin.CEnumerationPtr(nodemap.GetNode("PixelFormat"))
            pixel_format_mono8 = pixel_format.GetEntryByName("Mono8")
            pixel_format.SetIntValue(pixel_format_mono8.GetValue())
            self.logger.info("图像格式已设置为 Mono8。")

            # 关闭自动曝光并设置曝光时间（单位：微秒）
            exposure_auto = self.camera.ExposureAuto
            exposure_auto.SetValue(PySpin.ExposureAuto_Off)
            exposure_time = self.camera.ExposureTime
            exposure_time.SetValue(exposure_time_value)
            self.logger.info(f"曝光时间已设置为 {exposure_time.GetValue()} 微秒。")

            # 关闭自动增益并设置增益（单位：dB）
            gain_auto = self.camera.GainAuto
            gain_auto.SetValue(PySpin.GainAuto_Off)
            gain = self.camera.Gain
            gain.SetValue(gain_value)
            self.logger.info(f"增益已设置为 {gain.GetValue()} dB。")

            # 关闭自动帧率并设置帧率（FPS）
            
            acquisition_frame_rate_auto = PySpin.CEnumerationPtr(nodemap.GetNode("AcquisitionFrameRateAuto"))
            acquisition_frame_rate_auto_off = acquisition_frame_rate_auto.GetEntryByName("Off")
            acquisition_frame_rate_auto.SetIntValue(acquisition_frame_rate_auto_off.GetValue())
            self.logger.info("自动帧率已关闭。")
            acquisition_frame_rate = PySpin.CFloatPtr(nodemap.GetNode("AcquisitionFrameRate"))
            acquisition_frame_rate.SetValue(frame_rate_value)
            self.logger.info(f"帧率已设置为 {acquisition_frame_rate.GetValue()} FPS。")

            return True
        except PySpin.SpinnakerException as ex:
            self.logger.error(f"配置相机参数时出错: {ex}")
            return False
    
    def setup(self, camera_index=CAMERA_CONFIG['index'], exposure_time_value=CAMERA_CONFIG['exposure_time'], gain_value=CAMERA_CONFIG['gain'], frame_rate_value=CAMERA_CONFIG['frame_rate']):
        """
        设置相机参数
        
        初始化相机并配置相机参数。
        
        参数:
            camera_index (int): 相机索引
            exposure_time_value (float): 曝光时间（微秒）
            gain_value (float): 增益值（dB）
            frame_rate_value (float): 帧率（FPS）
            
        返回:
            bool: 设置是否成功
        """
        if not self.init_camera(camera_index):
            return False
            
        if not self.configure_camera(exposure_time_value, gain_value, frame_rate_value):
            return False
            
        return True
    
    def begin_acquisition(self):
        """
        开始图像采集
        
        返回:
            bool: 是否成功开始采集
        """
        if not self.is_initialized or self.camera is None:
            self.logger.error("相机未初始化，无法开始采集")
            return False
            
        try:
            self.camera.BeginAcquisition()
            self.is_acquiring = True
            return True
        except PySpin.SpinnakerException as ex:
            self.logger.error(f"开始图像采集时出错: {ex}")
            return False
    
    def get_next_image(self):
        """
        获取下一帧图像
        
        返回:
            tuple: (成功标志, 图像数据, 图像结果对象)
                成功时返回 (True, 矫正后的图像数据, 图像结果对象)
                失败时返回 (False, None, None)
        """
        if not self.is_acquiring or self.camera is None:
            self.logger.error("相机未在采集状态，无法获取图像")
            return False, None, None
            
        try:
            image_result = self.camera.GetNextImage()
            if image_result.IsIncomplete():
                self.logger.warning(f"获取的图像不完整: {image_result.GetImageStatus()}")
                image_result.Release()
                return False, None, image_result
                
            image_data = image_result.GetNDArray()
            
            # 根据设置决定是否进行畸变矫正
            if self.enable_undistort:
                corrected_image = self.undistort_image(image_data)
            else:
                corrected_image = image_data
            
            return True, corrected_image, image_result
        except PySpin.SpinnakerException as ex:
            self.logger.error(f"获取图像时出错: {ex}")
            return False, None, None
    
    def process_image(self, image, roi_x = ROI_CONFIG['x'], roi_y = ROI_CONFIG['y'], roi_width= ROI_CONFIG['width'], roi_height= ROI_CONFIG['height'], area_threshold=100, binary_threshold=160):
        """
        处理图像
        
        对图像进行处理，包括ROI提取、二值化、轮廓检测等。
        
        参数:
            image (ndarray): 输入图像
            roi_x, roi_y (int): ROI左上角坐标
            roi_width, roi_height (int): ROI宽度和高度
            area_threshold (float): 面积阈值，小于此值的轮廓将被忽略
            binary_threshold (int): 二值化阈值
            
        返回:
            tuple: (处理后的图像, 检测到的矩形信息)
        """
        try:
            # 提取ROI
            roi = image[roi_y:roi_y+roi_height, roi_x:roi_x+roi_width]
            # 二值化
            _, binary = cv2.threshold(roi, binary_threshold, 255, cv2.THRESH_BINARY)
            binary = ~binary
            # 轮廓检测
            contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            # 绘制原始图像的副本
            drawn_image = cv2.cvtColor(image.copy(), cv2.COLOR_GRAY2BGR)
            # 绘制ROI区域
            cv2.rectangle(drawn_image, (roi_x, roi_y), (roi_x+roi_width, roi_y+roi_height), (0, 255, 0), 2)
            
        
            #  绘制轨迹
            # path = plot_straight_line()
            path = plot_one_period_sine()
            cv2.polylines(drawn_image, [path.astype(np.int32)], False, (0, 0, 255), 5, lineType=cv2.LINE_AA, shift=0)
            
            # 初始化矩形信息
            rect_info = None
            # 处理轮廓
            for contour in contours:
                area = cv2.contourArea(contour)
                if area < area_threshold:
                    continue
                    
                # 获取最小外接矩形（用于绘制和尺寸信息）
                rect = cv2.minAreaRect(contour)
                box = cv2.boxPoints(rect)
                box = box.astype(int)
               
                # 计算中心点（相对于整个图像）
                center_x = rect[0][0] + roi_x
                center_y = rect[0][1] + roi_y
                
                # 计算朝向角度
                ang = rect[2]
                
                if rect[1][0]>rect[1][1]:   # 宽大于高
                    ang = ang + 90
                ang = 90-ang

                # 角度解缠绕法
                if self.last_ang is not None:
                    diff = ang - self.last_ang
                    if   diff >  80: ang -= 90
                    elif diff < -80: ang += 90

                self.last_ang = ang

                # 绘制轮廓和矩形
                cv2.drawContours(drawn_image, [box + (roi_x, roi_y)], 0, (0, 0, 255), 2)
                cv2.circle(drawn_image, (int(center_x), int(center_y)), 5, (255, 0, 0), -1)
                
                # 更新矩形信息
                rect_info = {
                    'center': (center_x, center_y),
                    'width': rect[1][0],
                    'height': rect[1][1],
                    'angle': ang,
                    'area': area
                }
                # 只处理第一个满足条件的轮廓
                break
                # 注意这里输出的drawn_image大小是2048*2048
            return drawn_image, rect_info
        except Exception as e:
            self.logger.error(f"处理图像时出错: {e}")
            return image, None
    
    def end_acquisition(self):
        """
        结束图像采集
        """
        if self.is_acquiring and self.camera is not None:
            try:
                self.camera.EndAcquisition()
                self.is_acquiring = False
                self.logger.info("图像采集已结束")
            except PySpin.SpinnakerException as ex:
                self.logger.error(f"结束图像采集时出错: {ex}")
    
    def release(self):
        """
        释放相机资源
        
        结束图像采集并释放相机资源。
        """
        try:
            if self.is_acquiring:
                self.end_acquisition()
                
            if self.camera is not None:
                self.camera.DeInit()
                del self.camera
                self.camera = None
                
            if self.camera_list is not None:
                self.camera_list.Clear()
                del self.camera_list
                self.camera_list = None
                
            if self.system is not None:
                self.system.ReleaseInstance()
                self.system = None
                
            self.is_initialized = False
            self.logger.info("相机资源已释放")
        except Exception as e:
            self.logger.error(f"释放相机资源时出错: {e}")