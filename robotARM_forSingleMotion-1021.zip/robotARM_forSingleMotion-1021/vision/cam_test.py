import cv2
import numpy as np
import logging
import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from vision.camera_manager import CameraManager
from utils.logger import setup_logger

# 全局变量存储点击的坐标点
clicked_points = []

def mouse_callback(event, x, y, flags, param):
    """
    鼠标点击回调函数
    
    参数:
        event: 鼠标事件类型
        x, y: 鼠标点击的坐标
        flags: 鼠标事件标志
        param: 传递的参数
    """
    if event == cv2.EVENT_LBUTTONDOWN:  # 左键点击
        # 添加点击点到列表
        clicked_points.append((x, y))
        print(f"鼠标点击坐标: ({x}, {y})")

def draw_clicked_points(image, points):
    """
    在图像上绘制点击的红点
    
    参数:
        image: 输入图像
        points: 点击点的坐标列表
        
    返回:
        绘制了红点的图像
    """
    result_image = image.copy()
    for point in points:
        cv2.circle(result_image, point, 5, (0, 0, 255), -1)  # 红色实心圆点
        # 添加坐标文本
        cv2.putText(result_image, f"({point[0]},{point[1]})", 
                   (point[0] + 10, point[1] - 10), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
    return result_image

def main():
    """
    主函数：测试相机管理器，实时显示图像并支持鼠标点击标记
    """
    # 设置日志
    logger = setup_logger("CameraTest", level=logging.INFO)
    
    # 创建相机管理器实例
    camera_manager = CameraManager(logger=logger, enable_undistort=True)
    
    try:
        # 初始化和配置相机
        logger.info("正在初始化相机...")
        if not camera_manager.setup():
            logger.error("相机初始化失败")
            return
        
        # 开始图像采集
        logger.info("开始图像采集...")
        if not camera_manager.begin_acquisition():
            logger.error("开始图像采集失败")
            return
        
        # 创建窗口并设置鼠标回调
        window_name = "Camera Test - Click to Mark Points"
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, 800, 800)  # 设置窗口大小为800x800
        cv2.setMouseCallback(window_name, mouse_callback)
        
        logger.info("相机测试开始，按 'q' 键退出，按 'c' 键清除所有标记点")
        logger.info("在窗口中点击鼠标左键可以标记红点并打印坐标")
        
        frame_count = 0
        
        while True:
            # 获取图像
            success, image, image_result = camera_manager.get_next_image()
            
            if success and image is not None:
                # 转换为BGR格式以便显示彩色标记
                if len(image.shape) == 2:  # 灰度图像
                    display_image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
                else:
                    display_image = image.copy()
                # 添加帧计数信息
                frame_count += 1
                cv2.putText(display_image, f"Frame: {frame_count}", 
                           (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
                # 添加点击点数量信息
                cv2.putText(display_image, f"Points: {len(clicked_points)}", 
                           (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
                # 添加操作提示
                cv2.putText(display_image, "Press 'q' to quit, 'c' to clear points", 
                           (10, display_image.shape[0] - 20), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                
                # 显示图像
                cv2.imshow(window_name, display_image)
                
                # 释放图像结果
                if image_result is not None:
                    image_result.Release()
            else:
                logger.warning("获取图像失败")
            
            # 处理键盘输入
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):  # 按 'q' 退出
                logger.info("用户请求退出")
                break
            elif key == ord('c'):  # 按 'c' 清除所有标记点
                clicked_points.clear()
                logger.info("已清除所有标记点")
                print("已清除所有标记点")
    
    except KeyboardInterrupt:
        logger.info("程序被用户中断")
    except Exception as e:
        logger.error(f"程序运行时出错: {e}")
    finally:
        # 清理资源
        logger.info("正在清理资源...")
        camera_manager.release()
        cv2.destroyAllWindows()
        
        # 打印所有点击的坐标
        if clicked_points:
            logger.info("所有点击的坐标:")
            for i, point in enumerate(clicked_points, 1):
                logger.info(f"  点 {i}: ({point[0]}, {point[1]})")
                print(f"点 {i}: ({point[0]}, {point[1]})")
        else:
            logger.info("没有点击任何点")

if __name__ == "__main__":
    main()